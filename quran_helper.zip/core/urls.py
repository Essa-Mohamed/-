"""
URL configuration for the core application.

These URLs map to the primary views: index, main menu, complaints,
and test selection. Namespaced under 'core' to avoid collisions.
"""
from django.urls import path  # type: ignore
from . import views

app_name = 'core'

urlpatterns = [
    path('', views.index, name='index'),
    path('home/', views.main_menu, name='main_menu'),
    path('complaint/', views.complaint, name='complaint'),
    path('test/', views.test_selection, name='test_selection'),
]
