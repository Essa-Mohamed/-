"""
Views for the Quran memorization assistant.

These views provide a minimal user flow: entering a student name,
displaying a main menu, submitting complaints, and selecting a test.
Further development is needed to implement the full testing logic.
"""
from django.shortcuts import render, redirect, get_object_or_404  # type: ignore
from django.contrib.auth.models import User  # type: ignore
from django.contrib import messages  # type: ignore

from .models import Student, Complaint
from .forms import StudentNameForm, ComplaintForm


def index(request):  # type: ignore
    """
    Entry point: ask for the student's name and create a user session.
    If a student already exists in session, redirect to main menu.
    """
    if request.session.get('student_id'):
        return redirect('core:main_menu')
    if request.method == 'POST':
        form = StudentNameForm(request.POST)
        if form.is_valid():
            display_name = form.cleaned_data['display_name']
            # Create a new Django user with a random username
            user = User.objects.create_user(username=f"user_{display_name}")
            student = Student.objects.create(user=user, display_name=display_name)
            request.session['student_id'] = student.id
            return redirect('core:main_menu')
    else:
        form = StudentNameForm()
    return render(request, 'core/index.html', {'form': form})


def main_menu(request):  # type: ignore
    """Display the main menu options for the logged‑in student."""
    student_id = request.session.get('student_id')
    if not student_id:
        return redirect('core:index')
    student = get_object_or_404(Student, pk=student_id)
    return render(request, 'core/main_menu.html', {'student': student})


def complaint(request):  # type: ignore
    """Allow the student to submit a complaint."""
    student_id = request.session.get('student_id')
    if not student_id:
        return redirect('core:index')
    student = get_object_or_404(Student, pk=student_id)
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            comp = form.save(commit=False)
            comp.student = student
            comp.save()
            messages.success(request, 'تم إرسال الشكوى بنجاح.')
            return redirect('core:main_menu')
    else:
        form = ComplaintForm()
    return render(request, 'core/complaint.html', {'form': form, 'student': student})


def test_selection(request):  # type: ignore
    """Stub view for selecting a test. In a real implementation, this would allow
    the student to choose Juz/quarters, test type, number of questions, and difficulty.
    Currently it displays a placeholder page.
    """
    student_id = request.session.get('student_id')
    if not student_id:
        return redirect('core:index')
    student = get_object_or_404(Student, pk=student_id)
    return render(request, 'core/test_selection.html', {'student': student})
