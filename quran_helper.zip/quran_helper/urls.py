"""
Root URL configuration for the Quran memorization assistant.

This file routes URLs to views. It includes the URLs of the
custom app `core` and the Django admin interface. When integrating
additional apps, include their URL configurations here.
"""
from django.contrib import admin  # type: ignore
from django.urls import path, include  # type: ignore


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('quran_helper.core.urls', namespace='core')),
]
