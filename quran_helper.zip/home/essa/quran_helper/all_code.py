# ===== FILE: core/admin.py =====
from django.contrib import admin
from django.contrib.auth.models import User, Group
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import (
    Complaint, Student, Juz, Quarter, SimilarityGroup, Ayah,
    TestSession, TestQuestion, Phrase, PhraseOccurrence
)

# --------- تخصيص عرض الـUsers في الأدمن ---------
# أخفي Groups (اختياري)
try:
    admin.site.unregister(Group)
except admin.sites.NotRegistered:
    pass

# لازم نفك تسجيل User الافتراضي قبل ما نعيد تسجيله
try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass

@admin.register(User)
class StaffOnlyUserAdmin(BaseUserAdmin):
    """اعرض في الأدمن المستخدمين الـstaff فقط."""
    def get_queryset(self, request):
     qs = super().get_queryset(request)
     return qs.filter(is_staff=True)

# --------- بقية الموديلات ---------
@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('student', 'short_text', 'created_at', 'resolved')
    list_filter = ('resolved', 'created_at', 'student')
    search_fields = ('text', 'student__display_name', 'student__user__username')
    raw_id_fields = ('student',)
    actions = ['mark_resolved']

    def short_text(self, obj):
        return obj.text[:50] + ('…' if len(obj.text) > 50 else '')
    short_text.short_description = 'نص مختصر'

    def mark_resolved(self, request, queryset):
        updated = queryset.update(resolved=True)
        self.message_user(request, f'{updated} شكوى تم تعليمها كمُحلّة.')
    mark_resolved.short_description = 'وضع كمُحلّل'

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('display_name', 'user')
    search_fields = ('display_name', 'user__username')

@admin.register(Phrase)
class PhraseAdmin(admin.ModelAdmin):
    list_display = ('text', 'length_words', 'global_freq', 'confusability')
    search_fields = ('text', 'normalized')

@admin.register(PhraseOccurrence)
class PhraseOccurrenceAdmin(admin.ModelAdmin):
    list_display = ('phrase', 'ayah', 'start_word', 'end_word')
    search_fields = ('phrase__text', 'ayah__surah', 'ayah__number')
    list_filter = ('phrase',)

# (لو حابب تضيف تسجيل لباقي الموديلات)
# admin.site.register(Juz)
# admin.site.register(Quarter)
# admin.site.register(SimilarityGroup)
# admin.site.register(Ayah)
# admin.site.register(TestSession)
# admin.site.register(TestQuestion)

# ===== FILE: core/forms.py =====
"""
Forms for the Quran memorization assistant.

These forms provide simple interfaces for capturing the student’s
display name and complaints. Additional forms for selecting tests
and answering questions can be implemented similarly.
"""
from django import forms  # type: ignore
from django.contrib.auth.models import User  # type: ignore
from .models import Complaint
from django.contrib.auth.forms import PasswordChangeForm


class StudentNameForm(forms.Form):
    """Capture a student’s display name to create a user account on the fly."""

    display_name = forms.CharField(label='اسم الطالب', max_length=100)


class ComplaintForm(forms.ModelForm):
    """Form for submitting a complaint."""

    class Meta:
        model = Complaint
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'rows': 4, 'cols': 40, 'placeholder': 'اكتب شكواك هنا...'}),
        }

class AccountForm(forms.Form):
    display_name = forms.CharField(label='اسم العرض', max_length=100)
    email = forms.EmailField(label='البريد الإلكتروني (اختياري)', required=False)
    avatar = forms.ImageField(label='الصورة الشخصية (اختياري)', required=False)

class PasswordChangeTightForm(PasswordChangeForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['old_password'].label = 'كلمة المرور الحالية'
        self.fields['new_password1'].label = 'كلمة المرور الجديدة'
        self.fields['new_password2'].label = 'تأكيد كلمة المرور الجديدة'

# ===== FILE: core/management/commands/__init__.py =====


# ===== FILE: core/management/commands/aggregatecodes.py =====
from django.core.management.base import BaseCommand
from pathlib import Path

class Command(BaseCommand):
    help = "جمع الملفات الرئيسية فقط داخل ملف واحد (افتراضيًا: all code.txt)"

    def add_arguments(self, parser):
        parser.add_argument(
            "--output", "-o",
            default="all code.txt",
            help="اسم الملف أو المسار النهائي (افتراضي: all code.txt). يقبل مسارًا مطلقًا أو نسبيًا."
        )

    def handle(self, *args, **options):
        # جذر المشروع (…/core/management/commands -> …/…/..)
        ROOT = Path(__file__).resolve().parents[3]

        # تحديد ملف الإخراج (يدعم المطلق/النسبي)
        out_opt = Path(options["output"])
        OUT = out_opt if out_opt.is_absolute() else (ROOT / out_opt)
        OUT.parent.mkdir(parents=True, exist_ok=True)

        # الملفات/الأنماط المطلوبة
        GLOBS = [
            "core/models.py",
            "core/views.py",
            "core/forms.py",
            "core/urls.py",
            "core/admin.py",
            "core/templates/core/**/*.html",
            "core/management/commands/*.py",
        ]
        IGNORE_PARTS = {
            "__pycache__", ".venv", "venv", ".git",
            "node_modules", "static", "media", "migrations"
        }

        def wanted(p: Path) -> bool:
            return all(part not in IGNORE_PARTS for part in p.parts)

        seen, files = set(), []
        for pattern in GLOBS:
            for p in ROOT.glob(pattern):
                if p.is_file() and wanted(p):
                    rp = p.relative_to(ROOT)
                    if rp not in seen:
                        seen.add(rp)
                        files.append(rp)

        files.sort(key=lambda x: str(x).lower())

        def read_text_safe(p: Path) -> str:
            try:
                return p.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                return p.read_text(encoding="latin-1")

        with OUT.open("w", encoding="utf-8") as f:
            for rp in files:
                content = read_text_safe(ROOT / rp)
                f.write(f"# ===== FILE: {rp.as_posix()} =====\n")
                f.write(content)
                if not content.endswith("\n"):
                    f.write("\n")
                f.write("\n")

        self.stdout.write(self.style.SUCCESS(
            f"تم تحديث {OUT} ({len(files)} ملف)."
        ))

# ===== FILE: core/management/commands/build_phrases_ngrams.py =====
from django.core.management.base import BaseCommand
from django.db import transaction
from core.models import Ayah, Phrase, PhraseOccurrence
import re, unicodedata
from collections import defaultdict

DIAC = re.compile(r'[\u064B-\u0652\u0670\u06DF-\u06ED]')
def normalize(txt: str) -> str:
    txt = unicodedata.normalize('NFKD', txt)
    txt = DIAC.sub('', txt)
    txt = (txt.replace('إ','ا').replace('أ','ا').replace('آ','ا')
               .replace('ة','ه').replace('ى','ي'))
    txt = re.sub(r'[^\w\s]', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return txt

class Command(BaseCommand):
    help = "Build Tarateel-like phrase index from Ayah.text using n-grams"

    def add_arguments(self, p):
        p.add_argument('--juz-from', type=int, default=1)
        p.add_argument('--juz-to', type=int, default=4)
        p.add_argument('--min-n', type=int, default=3)
        p.add_argument('--max-n', type=int, default=7)
        p.add_argument('--min-freq', type=int, default=2)
        p.add_argument('--max-freq', type=int, default=60)

    @transaction.atomic
    def handle(self, *a, **o):
        jf, jt = o['juz_from'], o['juz_to']
        min_n, max_n = o['min_n'], o['max_n']
        min_f, max_f = o['min_freq'], o['max_freq']

        # اجمع آيات النطاق
        ayat = (Ayah.objects
                .filter(quarter__juz__number__gte=jf, quarter__juz__number__lte=jt)
                .select_related('quarter__juz')
                .order_by('surah','number'))

        # ابنِ n-grams
        occs = defaultdict(list)   # norm_phrase -> list of (ayah_id, s, e, raw_text)
        for a in ayat:
            words = a.text.split()
            words_norm = [normalize(w) for w in words]
            L = len(words)
            for n in range(min_n, max_n+1):
                if n > L: break
                for i in range(0, L-n+1):
                    raw = " ".join(words[i:i+n]).strip()
                    norm = normalize(raw)
                    if len(norm.split()) < min_n:  # أمان إضافي
                        continue
                    occs[norm].append((a.id, i+1, i+n, raw))

        # فلترة بالتكرار
        kept = {k:v for k,v in occs.items() if min_f <= len(v) <= max_f}

        # تجميع حسب مجموعة الآيات المتطابقة ثم اختيار "الأطول"
        groups = defaultdict(list)  # frozenset(ayah_ids) -> [ (norm, occ_list) ]
        for norm, v in kept.items():
            ayids = frozenset(o[0] for o in v)
            groups[ayids].append((norm, v))

        PhraseOccurrence.objects.all().delete()
        Phrase.objects.all().delete()

        total_phrases = 0
        total_occ = 0
        for ayids, items in groups.items():
            # اختَر الأطول (بعدد الكلمات) ثم الأكثر وضوحاً كبديل
            items.sort(key=lambda x: (-len(x[0].split()), -len(x[1])))
            norm, v = items[0]
            # استخدم أول raw كعرض
            display_text = v[0][3]
            ph = Phrase.objects.create(
                text=display_text,
                normalized=norm,
                length_words=len(norm.split()),
                global_freq=len(v)
            )
            total_phrases += 1
            for ay_id, s, e, _ in v:
                PhraseOccurrence.objects.create(
                    phrase=ph, ayah_id=ay_id, start_word=s, end_word=e
                )
                total_occ += 1

        self.stdout.write(self.style.SUCCESS(
            f"Built phrases: {total_phrases}, occurrences: {total_occ}"
        ))

# ===== FILE: core/management/commands/import_page_images.py =====
# core/management/commands/import_page_images.py

import os
from pathlib import Path
from django.core.files import File
from django.core.management.base import BaseCommand
from core.models import Page

class Command(BaseCommand):
    help = "Attach Mushaf page images into Page.image (by page number)."

    def add_arguments(self, p):
        p.add_argument('--images-dir', required=True, help='Folder with page SVG/PNG files')
        p.add_argument('--img-pattern', default='{:03d}.svg', help="Filename pattern, e.g. '{:03d}.svg' or 'page_{:03d}.svg'")
        p.add_argument('--pages', type=int, default=80, help='How many pages to process (start from 1)')

    def handle(self, *args, **options):
        img_dir = Path(options['images_dir'])       # <-- بدل images-dir
        patt    = options['img_pattern']            # <-- بدل img-pattern
        pages   = int(options['pages'])

        total = 0
        for i in range(1, pages+1):
            p, _ = Page.objects.get_or_create(number=i)
            if p.image and p.image.name:
                continue
            img_path = img_dir / patt.format(i)
            if not img_path.exists():
                self.stdout.write(self.style.WARNING(f"Missing file: {img_path}"))
                continue
            with img_path.open('rb') as f:
                p.image.save(img_path.name, File(f), save=True)
                total += 1
        self.stdout.write(self.style.SUCCESS(f"Attached images to {total} pages."))

# ===== FILE: core/management/commands/import_quran_data.py =====
from django.core.management.base import BaseCommand
from core.models import Juz, Quarter, Ayah, Phrase, PhraseOccurrence
import json
from pathlib import Path
import re
import unicodedata
from collections import defaultdict

# -------- إعدادات النطاق --------
FIRST_JUZ = 1
LAST_JUZ  = 4

# -------- أدوات التطبيع --------
DIAC = re.compile(r'[\u064B-\u0652\u0670\u06DF-\u06ED]')

def normalize(txt: str) -> str:
    """تطبيع نص عربي: إزالة التشكيل وتوحيد الهمزات والتاء المربوطة… إلخ."""
    txt = unicodedata.normalize('NFKD', txt)
    txt = DIAC.sub('', txt)
    txt = (txt
           .replace('إ', 'ا')
           .replace('أ', 'ا')
           .replace('آ', 'ا')
           .replace('ة', 'ه')
           .replace('ى', 'ي'))
    txt = re.sub(r'[^\w\s]', ' ', txt)
    txt = re.sub(r'\s+', ' ', txt).strip()
    return txt

def find_span(words_norm, phrase_norm_words):
    """
    ابحث عن span لأول تطابق كامل للعبارة (مطبّعة) داخل كلمات آية مطبّعة.
    يرجع مؤشرين 1-based شاملين (start_word, end_word) أو None.
    """
    L = len(phrase_norm_words)
    if L == 0:
        return None
    for i in range(0, len(words_norm) - L + 1):
        if words_norm[i:i+L] == phrase_norm_words:
            return (i + 1, i + L)  # 1-based inclusive
    return None

def _sanitize_span(span, words_len):
    """توحيد/تصحيح span ليكون 1-based inclusive وداخل حدود عدد كلمات الآية."""
    if not span or len(span) < 2:
        return None
    try:
        s = int(span[0]); e = int(span[1])
    except Exception:
        return None
    # لو المؤشرات 0-based حوّلها لـ 1-based
    if s == 0 or e == 0:
        s += 1; e += 1
    if s > e:
        s, e = e, s
    # قصّ على حدود الكلمات
    s = max(1, min(s, words_len))
    e = max(1, min(e, words_len))
    return (s, e)

def _parse_match_words(match_words):
    """
    يحاول استخراج (src_span, tgt_span) من صيغ متعددة لـ match_words:
    أمثلة مدعومة:
    - [[src_start, src_end], [tgt_start, tgt_end], ...]
    - [[src_start, src_end]]
    - [ [ [src_start,src_end], [tgt_start,tgt_end] ], ... ]  (متشعب)
    - [{'source':[s,e], 'target':[s,e]}, ...]
    - [list of word indices]  -> يتحول لـ (min,max) كمصدر فقط
    يرجع (src_span, tgt_span) أو (None, None) إن فشل.
    """
    src_span = None
    tgt_span = None
    mw = match_words

    if not isinstance(mw, list) or not mw:
        return (None, None)

    x = mw[0]

    # dict بشكل واضح
    if isinstance(x, dict):
        if isinstance(x.get('source'), list) and len(x['source']) >= 2:
            src_span = (x['source'][0], x['source'][1])
        if isinstance(x.get('target'), list) and len(x['target']) >= 2:
            tgt_span = (x['target'][0], x['target'][1])
        return (src_span, tgt_span)

    # زوج أزواج: [ [s1,e1], [s2,e2] ]
    if isinstance(x, list) and len(x) == 2 and all(isinstance(v, list) for v in x):
        if len(x[0]) >= 2:
            src_span = (x[0][0], x[0][1])
        if len(x[1]) >= 2:
            tgt_span = (x[1][0], x[1][1])
        return (src_span, tgt_span)

    # [s,e] مصدر فقط
    if isinstance(x, list) and len(x) >= 2 and all(isinstance(v, (int, float, str)) for v in x[:2]):
        src_span = (x[0], x[1])
        return (src_span, tgt_span)

    # لستة مؤشرات [5,6,7] -> (5,7)
    if isinstance(x, list) and all(isinstance(v, (int, float, str)) for v in x):
        xs = [int(v) for v in x]
        src_span = (min(xs), max(xs))
        return (src_span, tgt_span)

    return (None, None)

class Command(BaseCommand):
    help = "Import Quran metadata + build Phrase & PhraseOccurrence from matching-ayah.json"

    def handle(self, *args, **opts):
        base_dir = Path(__file__).resolve().parent.parent.parent.parent
        data_dir = base_dir / "data"

        ayah_path   = data_dir / "quran-metadata-ayah.json"
        juz_path    = data_dir / "quran-metadata-juz.json"
        rub_path    = data_dir / "quran-metadata-rub.json"
        match_path  = data_dir / "matching-ayah.json"

        for p in (ayah_path, juz_path, rub_path, match_path):
            if not p.exists():
                self.stderr.write(f"❌ Missing {p}")
                return

        ayah_data = json.loads(ayah_path.read_text(encoding="utf-8"))
        juz_data  = json.loads(juz_path.read_text(encoding="utf-8"))
        rub_data  = json.loads(rub_path.read_text(encoding="utf-8"))
        matches   = json.loads(match_path.read_text(encoding="utf-8"))

        # -------- أجزاء Juz --------
        juz_map = {}   # verse_key -> juz_no
        created_juz = []
        for j_no_str, info in juz_data.items():
            j_no = int(j_no_str)
            if not (FIRST_JUZ <= j_no <= LAST_JUZ):
                continue
            Juz.objects.get_or_create(number=j_no)
            created_juz.append(j_no)
            for s_str, rng in info.get("verse_mapping", {}).items():
                s = int(s_str)
                a1, a2 = map(int, rng.split('-'))
                for a in range(a1, a2 + 1):
                    juz_map[f"{s}:{a}"] = j_no
        self.stdout.write(f"✔️ Juz done: {created_juz}")

        # -------- أرباع (Rubʿ) -> Quarter --------
        rub_quarter = {}
        idx_in_juz = defaultdict(int)
        # رتب بالأرقام
        for rub_no_str, info in sorted(rub_data.items(), key=lambda x: int(x[0])):
            verses = []
            for s_str, rng in info.get("verse_mapping", {}).items():
                s = int(s_str); a1, a2 = map(int, rng.split('-'))
                verses += [f"{s}:{a}" for a in range(a1, a2 + 1)]
            if not verses:
                continue
            vk0 = verses[0]
            j_no = juz_map.get(vk0)
            if not j_no or j_no > LAST_JUZ:
                continue
            idx_in_juz[j_no] += 1
            juz_obj = Juz.objects.get(number=j_no)

            # أول 3 كلمات من أول آية كـ label للربع
            first_text = next((v["text"] for v in ayah_data.values() if v["verse_key"] == vk0), "")
            label = " ".join(first_text.split()[:3]) if first_text else f"Quarter {idx_in_juz[j_no]}"
            q_obj, _ = Quarter.objects.get_or_create(
                juz=juz_obj,
                index_in_juz=idx_in_juz[j_no],
                defaults={"label": label}
            )
            rub_quarter[int(rub_no_str)] = q_obj
        self.stdout.write("✔️ Quarters done")

        # -------- إنشاء/تحديث آيات --------
        for v in ayah_data.values():
            vk = v["verse_key"]
            j_no = juz_map.get(vk)
            if not j_no or j_no > LAST_JUZ:
                continue
            Ayah.objects.update_or_create(
                surah=v["surah_number"],
                number=v["ayah_number"],
                defaults={"text": v["text"]}
            )

        # -------- ربط الآيات بالأرباع --------
        for rub_no_str, info in sorted(rub_data.items(), key=lambda x: int(x[0])):
            rub_no = int(rub_no_str)
            q_obj = rub_quarter.get(rub_no)
            if not q_obj:
                continue
            for s_str, rng in info.get("verse_mapping", {}).items():
                s = int(s_str); a1, a2 = map(int, rng.split('-'))
                for a in range(a1, a2 + 1):
                    Ayah.objects.filter(surah=s, number=a).update(quarter=q_obj)
        self.stdout.write("✔️ Ayah objects assigned to quarters")

        # -------- بناء Phrase & PhraseOccurrence --------
        # تنظيف القديم لبناء نظيف
        PhraseOccurrence.objects.all().delete()
        Phrase.objects.all().delete()

        # كاش الكلمات المطبّعة لكل آية
        words_cache = {}   # verse_key -> (words_raw, words_norm)
        ayah_by_key = {}   # "s:a" -> Ayah instance
        for v in ayah_data.values():
            vk = v["verse_key"]
            j_no = juz_map.get(vk)
            if not j_no or j_no > LAST_JUZ:
                continue
            words_raw = v["text"].split()
            words_norm = [normalize(w) for w in words_raw]
            words_cache[vk] = (words_raw, words_norm)
            try:
                ayah_by_key[vk] = Ayah.objects.get(surah=v["surah_number"], number=v["ayah_number"])
            except Ayah.DoesNotExist:
                pass

        phrase_map = {}   # normalized -> Phrase
        total_occ = 0
        total_phrases = 0

        # مرّن التعامل مع match_words
        for src_vk, lst in matches.items():
            if src_vk not in words_cache:
                continue
            for m in lst:
                pairs = m.get("match_words") or []
                words_raw, words_norm = words_cache[src_vk]
                src_span, tgt_span = _parse_match_words(pairs)

                # سدّد وصحّح span المصدر
                src_span = _sanitize_span(src_span, len(words_raw)) if src_span else None
                if not src_span:
                    # لا نعلم حدود المصدر بدقة؛ نترك هذا التطابق
                    continue

                s1, e1 = src_span
                phrase_words_raw = words_raw[s1 - 1:e1]
                phrase_text = " ".join(phrase_words_raw).strip()
                phrase_norm = normalize(phrase_text)
                phrase_norm_words = phrase_norm.split()
                if len(phrase_norm_words) < 2:
                    # تجاهل العبارات القصيرة جداً
                    continue

                # أنشئ/أحضر Phrase
                ph = phrase_map.get(phrase_norm)
                if ph is None:
                    ph = Phrase.objects.create(
                        text=phrase_text,
                        normalized=phrase_norm,
                        length_words=len(phrase_norm_words),
                        global_freq=0
                    )
                    phrase_map[phrase_norm] = ph
                    total_phrases += 1

                # occurrence في آية المصدر
                src_ayah = ayah_by_key.get(src_vk)
                if src_ayah:
                    PhraseOccurrence.objects.get_or_create(
                        phrase=ph, ayah=src_ayah,
                        start_word=s1, end_word=e1
                    )
                    total_occ += 1

                # occurrence في آية الهدف
                tgt_vk = m.get("matched_ayah_key")
                if tgt_vk and tgt_vk in words_cache:
                    t_words_raw, t_words_norm = words_cache[tgt_vk]
                    tgt_ayah = ayah_by_key.get(tgt_vk)

                    span = None
                    if tgt_span:
                        span = _sanitize_span(tgt_span, len(t_words_raw))
                    if not span:
                        span = find_span(t_words_norm, phrase_norm_words)

                    if tgt_ayah and span:
                        s2, e2 = span
                        PhraseOccurrence.objects.get_or_create(
                            phrase=ph, ayah=tgt_ayah,
                            start_word=s2, end_word=e2
                        )
                        total_occ += 1

        # حدّث global_freq لكل Phrase
        for ph in Phrase.objects.all():
            cnt = PhraseOccurrence.objects.filter(phrase=ph).count()
            ph.global_freq = cnt
            # confusability ممكن نحسبها لاحقًا (مثال: cnt / length_words)
            ph.save(update_fields=['global_freq'])

        self.stdout.write(f"✔️ Phrases: {total_phrases}, Occurrences: {total_occ}")
        self.stdout.write(self.style.SUCCESS("تم الاستيراد وبناء العبارات بنجاح 🎉"))

# ===== FILE: core/management/commands/link_ayat_to_pages.py =====
import sqlite3
from pathlib import Path
from django.core.management.base import BaseCommand
from core.models import Ayah, Page

# هنحاول نكتشف أسماء الأعمدة الشائعة في جدول words تلقائيًا
WORDS_COL_SETS = [
    # (word_index, surah, ayah)
    ("word_index", "surah", "ayah"),
    ("word_index", "sura", "aya"),
    ("word_index", "surah_number", "ayah_number"),
    ("id", "surah", "ayah"),
    ("id", "surah_number", "ayah_number"),
]

class Command(BaseCommand):
    help = "Link Ayah.page using mushaf layout (pages table) + words DB (words table)."

    def add_arguments(self, parser):
        parser.add_argument('--layout-sqlite', required=True,
                            help='Path to mushaf-madinah-v1.db (has pages/info)')
        parser.add_argument('--words-sqlite', required=True,
                            help='Path to QPC V1 Glyphs – Word by Word.db (has words)')
        parser.add_argument('--pages', type=int, default=604,
                            help='Total pages in mushaf (default 604)')
        parser.add_argument('--limit-pages', type=int, default=0,
                            help='If >0, only process up to this page number')

    def _detect_words_schema(self, conn):
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(words)")
        cols = [r[1].lower() for r in cur.fetchall()]
        for wi, su, ay in WORDS_COL_SETS:
            if wi.lower() in cols and su.lower() in cols and ay.lower() in cols:
                return wi, su, ay
        raise RuntimeError(f"Could not detect columns in 'words'. Found: {cols}")

    def handle(self, *args, **options):
        layout_path = Path(options['layout_sqlite'])
        words_path  = Path(options['words_sqlite'])
        limit_pages = int(options['limit_pages']) or None

        if not layout_path.exists():
            self.stderr.write(f"Layout DB not found: {layout_path}")
            return
        if not words_path.exists():
            self.stderr.write(f"Words DB not found:  {words_path}")
            return

        # افتح قاعدة الكلمات واكتشف أسماء الأعمدة
        con_words  = sqlite3.connect(str(words_path))
        wi, su, ay = self._detect_words_schema(con_words)
        curw = con_words.cursor()
        self.stdout.write(f"Detected words schema: ({wi}, {su}, {ay})")

        # ابنِ خريطة word_index -> (surah, ayah)
        curw.execute(f"SELECT {wi}, {su}, {ay} FROM words")
        wmap = {}
        for wid, s, a in curw.fetchall():
            try:
                wid_i = int(wid); s_i = int(s); a_i = int(a)
            except Exception:
                continue
            wmap[wid_i] = (s_i, a_i)
        self.stdout.write(f"Loaded {len(wmap):,} words.")

        # افتح قاعدة الـlayout
        con_layout = sqlite3.connect(str(layout_path))
        curl = con_layout.cursor()

        # هات سطور الآيات مع نطاق الكلمات
        curl.execute("""
            SELECT page_number, line_number, line_type, first_word_id, last_word_id
            FROM pages
            WHERE line_type='ayah'
        """)
        lines = curl.fetchall()

        total_lines = 0
        linked = 0
        for page_number, line_number, line_type, first_w, last_w in lines:
            if not first_w or not last_w:
                continue
            try:
                pno = int(page_number)
            except Exception:
                continue
            if limit_pages and pno > limit_pages:
                continue

            # كل سطر قد يحتوي على جزء من آية أو أكثر — ناخد كل (سورة، آية) ظهرت في نطاق الكلمات
            seen_pairs = set()
            try:
                fw = int(first_w); lw = int(last_w)
            except Exception:
                continue
            if fw > lw:
                fw, lw = lw, fw

            for wid in range(fw, lw + 1):
                sa = wmap.get(wid)
                if sa:
                    seen_pairs.add(sa)

            if not seen_pairs:
                total_lines += 1
                continue

            # اربط كل آية بأول صفحة تظهر فيها
            page_obj, _ = Page.objects.get_or_create(number=pno)
            for (s, a) in seen_pairs:
                try:
                    ayah = Ayah.objects.get(surah=s, number=a)
                except Ayah.DoesNotExist:
                    continue
                if ayah.page_id is None or (ayah.page and pno < ayah.page.number):
                    ayah.page = page_obj
                    ayah.save(update_fields=['page'])
                    linked += 1

            total_lines += 1

        self.stdout.write(self.style.SUCCESS(
            f"Processed {total_lines:,} ayah-lines. Linked/updated {linked:,} ayat to pages."
        ))

# ===== FILE: core/models.py =====
"""
Database models for the Quran memorization assistant.

These models define the fundamental data structures required
to support users (students), complaints, Quranic metadata, and
test sessions. They are simplified placeholders; relationships
can be expanded to cover more advanced features.
"""
from django.db import models  # type: ignore
from django.contrib.auth.models import User  # type: ignore


class Student(models.Model):
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    def avatar_url(self):
        try:
            if self.avatar and hasattr(self.avatar, "url"):
                return self.avatar.url
        except Exception:
            pass
        return ""  # هنستخدم شكل افتراضي بالـCSS لو فاضي
    """A simple student profile linked to the built-in User model."""

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    display_name = models.CharField(max_length=100)

    def __str__(self) -> str:
        return self.display_name


class Complaint(models.Model):
    """A complaint or suggestion submitted by a student."""

    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f"Complaint by {self.student}: {self.text[:30]}"


class Juz(models.Model):
    """Represents one of the 30 parts of the Qur’an."""

    number = models.PositiveSmallIntegerField(unique=True)
    name = models.CharField(max_length=50, blank=True)

    def __str__(self) -> str:
        return f"Juz {self.number}"


class Quarter(models.Model):
    """Represents a quarter of a Juz (Rubʿ)."""

    juz = models.ForeignKey(Juz, on_delete=models.CASCADE)
    index_in_juz = models.PositiveSmallIntegerField(help_text="1–8 for each Juz")
    label = models.CharField(max_length=100, help_text="Name of the quarter from the opening words of its first verse")

    class Meta:
        unique_together = ('juz', 'index_in_juz')

    def __str__(self) -> str:
        return f"{self.juz} - Quarter {self.index_in_juz}"


class Page(models.Model):
    """Represents a page of the Mushaf with its image."""

    number = models.PositiveSmallIntegerField(unique=True)
    image = models.ImageField(upload_to='pages/')

    def __str__(self) -> str:
        return f"Page {self.number}"


class Ayah(models.Model):
    """Represents a single ayah with its metadata."""

    surah = models.PositiveSmallIntegerField()
    number = models.PositiveSmallIntegerField()
    text = models.TextField()
    page = models.ForeignKey(Page, on_delete=models.SET_NULL, null=True, blank=True)
    quarter = models.ForeignKey(Quarter, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        unique_together = ('surah', 'number')

    def __str__(self) -> str:
        return f"{self.surah}:{self.number}"


class SimilarityGroup(models.Model):
    """Group of similar verses (mutashabehat)."""

    name = models.CharField(max_length=200, help_text="Key phrase that identifies the group")
    ayat = models.ManyToManyField(Ayah, related_name='similarity_groups')

    def __str__(self) -> str:
        return self.name


class Phrase(models.Model):
    text = models.CharField(max_length=200)
    normalized = models.CharField(max_length=200, db_index=True)
    length_words = models.PositiveSmallIntegerField()
    global_freq = models.PositiveIntegerField(default=0)
    confusability = models.FloatField(default=0.0)

    def __str__(self):
        return self.text


class PhraseOccurrence(models.Model):
    phrase = models.ForeignKey(Phrase, related_name='occurrences', on_delete=models.CASCADE)
    ayah = models.ForeignKey(Ayah, on_delete=models.CASCADE)
    start_word = models.PositiveSmallIntegerField()
    end_word = models.PositiveSmallIntegerField()

    class Meta:
        unique_together = ('phrase', 'ayah', 'start_word', 'end_word')
        indexes = [
            models.Index(fields=['ayah']),
            models.Index(fields=['phrase']),
        ]


class TestSession(models.Model):
    """Represents one attempt of a test by a student."""

    # NEW: أنواع الاختبارات (الجديدة + القديمة حفاظًا على التوافق)
    TEST_TYPE_CHOICES = [
        ('similar_count', 'عدد مواضع المتشابهات'),                 # المتاح حاليًا
        ('similar_on_pages', 'مواضع المتشابهات في الصفحات'),        # قريبًا
        ('page_edges_quarters', 'بداية/نهاية الصفحات مع الأرباع'),   # قريبًا
        ('order_juz_quarters', 'ترتيب الأجزاء والأرباع'),            # قريبًا
        ('semantic_similarities', 'متشابهات معاني الآيات'),          # قريبًا

        # القيم القديمة إن كانت موجودة في بيانات سابقة:
        ('similar_only', 'Similar verses only'),
        ('similar_quarters', 'Similar verses & quarters'),
        ('similar_quarters_location', 'Similar verses & quarters with location'),
        ('mixed', 'Mixed'),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    test_type = models.CharField(
        max_length=50,
        choices=TEST_TYPE_CHOICES,
        default='similar_count',
    )
    num_questions = models.PositiveSmallIntegerField(default=10)
    difficulty = models.CharField(
        max_length=10,
        choices=[('easy', 'Easy'), ('medium', 'Medium'), ('hard', 'Hard')],
        default='easy',
    )
    completed = models.BooleanField(default=False)

    # ManyToMany to Juz and Quarter representing scope
    juzs = models.ManyToManyField(Juz, blank=True)
    quarters = models.ManyToManyField(Quarter, blank=True)

    def __str__(self) -> str:
        return f"TestSession {self.id} for {self.student}"


class TestQuestion(models.Model):
    """Single question within a test session."""

    session = models.ForeignKey(TestSession, on_delete=models.CASCADE, related_name='questions')
    similarity_group = models.ForeignKey(SimilarityGroup, on_delete=models.SET_NULL, null=True)
    # store JSON or text representing the student's answer. In a complete implementation
    # this could be structured data (quarter ID, page number, half, etc.).
    student_response = models.TextField(blank=True)
    is_correct = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f"Question {self.id} in {self.session}"

# ===== FILE: core/templates/core/_progress.html =====
{# core/_progress.html #}
<div class="progress-wrap" dir="ltr" style="--ring:#2a3342; --track:#364152; --val:#f1cf6b">
  <svg class="progress" viewBox="0 0 120 120" aria-label="{{ aria_label|default:'Progress' }}">
    <circle class="progress-bg" cx="60" cy="60" r="52"></circle>
    <circle class="progress-track" cx="60" cy="60" r="52"></circle>
    <circle class="progress-value" cx="60" cy="60" r="52"></circle>
  </svg>
  <div class="progress-text">
    <div class="progress-main"><span id="progressPct">{{ pct|default:0 }}</span>%</div>
    {% if step_no and target_total %}
      <div class="progress-sub">{{ step_no }}/{{ target_total }}</div>
    {% elif sub_label %}
      <div class="progress-sub">{{ sub_label }}</div>
    {% endif %}
  </div>
</div>

<style>
.progress-wrap{
  position:relative; width:140px; height:140px;
  display:inline-flex; align-items:center; justify-content:center;
}
.progress{ width:100%; height:100%; filter: drop-shadow(0 1px 2px rgba(0,0,0,.25)); }
.progress-bg{ fill:none; stroke: var(--ring,#2a3342); stroke-width: 9; }
.progress-track{ fill:none; stroke: var(--track,#3a475c); stroke-width: 10; opacity:.85; }
.progress-value{
  fill:none; stroke: var(--val,#f1cf6b);
  stroke-width: 10; stroke-linecap: round;
  transform: rotate(-90deg); transform-origin: 60px 60px;
  stroke-dasharray: 327; stroke-dashoffset: 327;
  transition: stroke-dashoffset .5s ease;
}
.progress-text{
  position:absolute; inset:0; display:flex; flex-direction:column;
  align-items:center; justify-content:center; text-align:center;
  font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Tahoma, Arial;
}
.progress-main{ font-size:22px; font-weight:900; line-height:1; color:#e5e7eb; letter-spacing:.3px; }
.progress-sub{ font-size:12px; color:#9aa3b2; margin-top:4px; }
@media (prefers-color-scheme: light){
  .progress-bg{ stroke:#f2f4f7 }
  .progress-track{ stroke:#e5e7eb }
  .progress-main{ color:#1f2937 }
  .progress-sub{ color:#64748b }
}
</style>

<script>
(function(){
  var pct = Number('{{ pct|default:0 }}') || 0;
  var circumference = 327; // 2πr حيث r=52
  var clamped = Math.max(0, Math.min(100, pct));
  var offset = circumference * (1 - clamped / 100);
  var ring = document.currentScript && document.currentScript.previousElementSibling ?
             document.currentScript.previousElementSibling.querySelector('.progress-value') :
             document.querySelector('.flow-hud .progress-value'); // fallback
  var label = document.currentScript && document.currentScript.previousElementSibling ?
             document.currentScript.previousElementSibling.querySelector('#progressPct') :
             document.getElementById('progressPct');
  if (ring) ring.style.strokeDashoffset = offset;
  if (label) label.textContent = clamped;
})();
</script>

# ===== FILE: core/templates/core/account_settings.html =====
{% extends "core/base.html" %}
{% load static i18n %}

{% block title %}إعدادات الحساب — متواتر{% endblock %}

{% block content %}
<style>
  .acc-wrap{max-width: 880px; margin: 18px auto; padding: 14px; display:grid; gap:14px}
  .acc-card{
    background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    border:1px solid rgba(255,255,255,.10);
    border-radius:16px; box-shadow:0 14px 36px rgba(0,0,0,.22);
    padding: 14px;
  }
  .acc-title{ margin:0 0 8px; color:#fff; font-weight:900 }
  .acc-grid{ display:grid; gap:10px }
  .row{ display:grid; gap:8px; align-items:center }
  .two{ grid-template-columns: 160px 1fr }
  @media (max-width:720px){ .two{ grid-template-columns: 1fr } }

  .avatar-lg{ width:84px; height:84px; border-radius:50%; overflow:hidden; background:#0f1118; border:1px solid rgba(255,255,255,.1); display:grid; place-items:center }
  .avatar-lg img{ width:100%; height:100%; object-fit:cover }
  .hint{ color:var(--muted); font-size:.92rem }
  .form-actions{ display:flex; gap:.6rem; flex-wrap:wrap; margin-top:6px }
  .btn-lg{ padding:.7rem 1rem; border-radius:12px; font-weight:900 }
  .input, input[type="file"]{ background:#0f1118; color:#fff; border:1px solid rgba(255,255,255,.12); border-radius:10px; padding:.55rem .65rem; width:100% }
  label{ color:#fff; font-weight:800 }
</style>

<div class="acc-wrap" dir="rtl">

  <!-- بيانات عامة + صورة -->
  <section class="acc-card">
    <h2 class="acc-title">بيانات الحساب</h2>
    <form method="post" enctype="multipart/form-data">
      {% csrf_token %}
      <input type="hidden" name="action" value="update_profile">
      <div class="acc-grid">
        <div class="row two">
          <label>الصورة الشخصية</label>
          <div style="display:flex; gap:10px; align-items:center">
            <span class="avatar-lg">
              {% if student.avatar %}
                <img src="{{ student.avatar.url }}" alt="">
              {% else %}
                <span style="color:#fff; font-weight:900; font-size:24px">{{ request.user.username|slice:":1"|upper }}</span>
              {% endif %}
            </span>
            <input type="file" name="avatar" accept="image/*">
            {% if student.avatar %}
              <label style="display:inline-flex; gap:.35rem; align-items:center">
                <input type="checkbox" name="remove_avatar" value="1">
                <span class="hint">حذف الصورة الحالية</span>
              </label>
            {% endif %}
          </div>
        </div>

        <div class="row two">
          <label for="id_display_name">اسم المستخدم:</label>
          <input type="text" id="id_display_name" name="display_name" class="input" value="{{ profile_form.display_name.value|default:student.display_name }}">
        </div>

        <div class="row two">
          <label for="id_email">البريد الإلكتروني:</label>
          <input type="email" id="id_email" name="email" class="input" placeholder="اختياري" value="{{ profile_form.email.value|default:request.user.email }}">
          <div class="hint">بعد حفظه، يمكنك تسجيل الدخول باسم المستخدم أو البريد الإلكتروني.</div>
        </div>

        <div class="form-actions">
          <button type="submit" class="btn btn-primary btn-lg">حفظ التغييرات</button>
          <a href="{% url 'core:main_menu' %}" class="btn btn-outline btn-lg">الرجوع للرئيسية</a>
        </div>
      </div>
    </form>
  </section>

  <!-- تغيير كلمة المرور -->
  <section class="acc-card">
    <h2 class="acc-title">تغيير كلمة المرور</h2>
    <form method="post">
      {% csrf_token %}
      <input type="hidden" name="action" value="change_password">
      <div class="acc-grid">
        <div class="row two">
          <label for="{{ password_form.old_password.id_for_label }}">كلمة المرور الحالية</label>
          {{ password_form.old_password }}
        </div>
        <div class="row two">
          <label for="{{ password_form.new_password1.id_for_label }}">كلمة المرور الجديدة</label>
          {{ password_form.new_password1 }}
        </div>
        <div class="row two">
          <label for="{{ password_form.new_password2.id_for_label }}">تأكيد كلمة المرور الجديدة</label>
          {{ password_form.new_password2 }}
        </div>
        <div class="hint">
          يجب ألا تقل عن 8 أحرف وتحتوي على أحرف وأرقام (وفقًا لمتطلبات الأمان).
        </div>
        <div class="form-actions">
          <button type="submit" class="btn btn-primary btn-lg">تحديث كلمة المرور</button>
        </div>
      </div>
    </form>
  </section>

</div>
{% endblock %}

# ===== FILE: core/templates/core/base.html =====
{% load i18n static %}<!doctype html><html lang="{{ LANGUAGE_CODE|default:'ar' }}" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{% block title %}متواتر{% endblock %}</title><link rel="stylesheet" href="{% static 'css/mutawatir.css' %}"><style>.btn{display:inline-flex;align-items:center;contain:layout paint;position:relative;overflow:hidden;transition:transform .12s,box-shadow .22s,background-color .22s,border-color .22s;will-change:transform}.badge-alpha{display:inline-block;margin-inline-start:.5rem;padding:.15rem .5rem;font-size:.75rem;border-radius:.5rem;border:1px solid #d9b44a;background:#fffbea;color:#8a6d1d;vertical-align:middle;white-space:nowrap}.topbar .container.row{display:flex;align-items:center;justify-content:space-between}.brand,.actions{display:flex;align-items:center}.actions{gap:.6rem;margin-inline-start:auto}.brand-link{display:flex;align-items:center;gap:.6rem;text-decoration:none}.brand-logo{width:42px;height:42px}.brand-text .brand-name-ar{font-size:1.18rem;font-weight:900;color:#fff}.brand-text .brand-name-en{font-size:.9rem;opacity:.9;color:#f1cf6b}.nav-welcome{display:inline-flex;align-items:center;gap:.45rem;direction:rtl;font-weight:800;color:#1b1b1b;background:linear-gradient(135deg,var(--accent,#f1cf6b),var(--accent-2,#f3e4a8));padding:.32rem .6rem;border-radius:999px;border:1px solid rgba(212,175,55,.55);box-shadow:0 6px 18px rgba(0,0,0,.12);font-size:.92rem}.nav-welcome .dot{width:10px;height:10px;border-radius:50%;background:#16a34a;box-shadow:0 0 0 6px rgba(22,163,74,.15);animation:pulse 1.8s ease-in-out infinite}@keyframes pulse{0%,100%{box-shadow:0 0 0 6px rgba(22,163,74,.15)}50%{box-shadow:0 0 0 9px rgba(22,163,74,.30)}}.user-cluster{position:relative;display:flex;align-items:center;gap:.6rem}.user-trigger{display:flex;align-items:center;gap:.5rem;background:transparent;border:0;cursor:pointer;padding:.25rem .4rem;border-radius:12px}.user-trigger:focus-visible{outline:none;box-shadow:0 0 0 3px rgba(241,207,107,.35)}.avatar{width:40px;height:40px;border-radius:50%;overflow:hidden;background:#0f1118;border:1px solid rgba(255,255,255,.1);display:inline-grid;place-items:center}.avatar img{width:100%;height:100%;object-fit:cover;display:block}.avatar-fallback{width:100%;height:100%;display:grid;place-items:center}.avatar-fallback svg{width:72%;height:72%}.btn:hover{transform:translateY(-1px);box-shadow:0 10px 24px rgba(0,0,0,.18)}.btn:active{transform:translateY(0);box-shadow:0 6px 16px rgba(0,0,0,.16)}.btn:focus-visible{outline:none;box-shadow:0 0 0 3px rgba(241,207,107,.45),0 10px 24px rgba(0,0,0,.18)}.btn.btn-primary{background:linear-gradient(135deg,var(--accent,#f1cf6b),var(--accent-2,#f3e4a8));color:#0e1a14;border-color:rgba(212,175,55,.65);font-weight:900}.btn.btn-outline{background:transparent;color:var(--accent,#f1cf6b);border:1px solid var(--accent,#f1cf6b);font-weight:800}.score-hud{position:fixed;top:8px;inset-inline:0;display:grid;justify-content:center;z-index:9998;pointer-events:none}.score-hud__chip{pointer-events:auto;display:inline-flex;align-items:center;gap:.6rem;background:rgba(2,6,23,.78);color:#fff;border:1px solid rgba(255,255,255,.14);padding:.35rem .65rem;border-radius:999px;backdrop-filter:blur(6px);box-shadow:0 10px 24px rgba(0,0,0,.25)}.score-hud__label{opacity:.85;font-weight:700}.score-hud__value{font-weight:900;font-variant-numeric:tabular-nums}.score-hud__delta{font-weight:900;font-variant-numeric:tabular-nums;padding:.05rem .5rem;border-radius:999px;border:1px solid transparent;transform:translateY(-4px);opacity:0;transition:all .28s;white-space:nowrap}.score-hud__delta.show{transform:translateY(0);opacity:1}.score-hud__delta.pos{background:#052e16;border-color:#166534;color:#22c55e}.score-hud__delta.neg{background:#3f0610;border-color:#7f1d1d;color:#f87171}.feedback{margin:.5rem auto 0;padding:.6rem .8rem;border-radius:12px;border:1px solid transparent;font-weight:800;text-align:center;max-width:900px}.feedback--success{background:#052e16;border-color:#166534;color:#22c55e}.feedback--warning{background:#3b2905;border-color:#a16207;color:#fbbf24}.feedback--error{background:#3f0610;border-color:#7f1d1d;color:#f87171}.feedback--info{background:#0b1220;border-color:#1f2a44;color:#93c5fd}.splash-overlay.hide{opacity:0;pointer-events:none}</style></head><body>{% if show_pages_progress %}<section class="flow-hud" role="region" aria-label="تقدّم الامتحان">{% include "core/_progress.html" with pct=progress_pct step_no=step_no target_total=target_total aria_label="Progress" %}</section>{% endif %}<header class="topbar"><div class="container row"><div class="brand"><a href="{% if request.user.is_authenticated %}{% url 'core:main_menu' %}{% else %}{% url 'core:landing' %}{% endif %}" class="brand-link" aria-label="Mutawatir Home"><img src="{% static 'img/logo.png' %}" srcset="{% static 'img/logo.png' %} 1x, {% static 'img/logo@2x.png' %} 2x" class="brand-logo" alt="Mutawatir Logo"><span class="brand-text"><span class="brand-name-ar">متواتر</span><span class="brand-name-en">Mutawatir</span></span>{% if IS_ALPHA %}<span class="badge-alpha" title="نسخة أولية قيد التطوير">{{ APP_VERSION }}</span>{% endif %}</a></div><nav class="actions">{% if request.user.is_authenticated %}<div class="user-cluster"><button type="button" class="user-trigger" id="userMenuBtn" aria-expanded="false"><span class="avatar" aria-hidden="true">{% if student and student.avatar %}<img src="{{ student.avatar.url }}" alt="">{% else %}<span class="avatar-fallback" aria-hidden="true"><svg viewBox="0 0 24 24" role="img" aria-label="user"><path d="M12 12c2.761 0 5-2.686 5-6s-2.239-6-5-6-5 2.686-5 6 2.239 6 5 6zm0 2c-4.418 0-8 2.239-8 5v1h16v-1c0-2.761-3.582-5-8-5z" fill="#9aa3b2"/></svg></span>{% endif %}</span><span class="nav-welcome" dir="rtl"><span class="dot" aria-hidden="true"></span>مرحبًا، {{ student.display_name|default:request.user.username }}</span><span class="caret" aria-hidden="true">▾</span></button>{% url 'core:account_settings' as account_url %}<div class="user-menu" id="userMenu" hidden><a href="{% url 'core:main_menu' %}" class="menu-item">الصفحة الرئيسية</a><a href="{% url 'core:complaint' %}" class="menu-item">الإبلاغ / اقتراح</a>{% if account_url %}<a href="{{ account_url }}" class="menu-item">إعدادات الحساب</a>{% endif %}<a href="{% url 'core:stats' %}" class="menu-item">إحصائياتك</a><a href="{% url 'core:logout' %}" class="menu-item">تسجيل الخروج</a></div></div>{% else %}<a class="btn btn-outline" href="{% url 'core:login' %}">{% trans "تسجيل الدخول" %}</a><a class="btn btn-primary" href="{% url 'core:signup' %}">{% trans "إنشاء حساب" %}</a>{% endif %}<form method="post" action="{% url 'set_language' %}" class="lang-form">{% csrf_token %}<select name="language" onchange="this.form.submit()" class="input small"><option value="ar" {% if LANGUAGE_CODE == 'ar' %}selected{% endif %}>العربية</option><option value="en" {% if LANGUAGE_CODE == 'en' %}selected{% endif %}>English</option></select><input type="hidden" name="next" value="{{ request.get_full_path }}"></form></nav></div></header>{% if show_score_hud %}<div id="score-hud" class="score-hud" data-score="{{ score|default:0 }}"{% if score_delta is not None %} data-delta="{{ score_delta }}"{% endif %}><div class="score-hud__chip"><span class="score-hud__label">نتيجتك</span><span class="score-hud__value" id="scoreValue">{{ score|default:0 }}</span><span class="score-hud__delta" id="scoreDelta" hidden></span></div></div>{% endif %}{% if not suppress_toasts %}<div id="toast-root" class="toast-root" aria-live="polite" aria-atomic="true"></div>{% if messages %}<div id="server-messages" class="sr-only">{% for message in messages %}<div data-level="{{ message.tags|default:'info' }}">{{ message }}</div>{% endfor %}</div>{% endif %}{% endif %}<main class="container">{% block content %}{% endblock %}</main>{% if not hide_footer %}<footer class="footer"><div class="container"><div class="muted">© متواتر — All rights reserved.{% if IS_ALPHA %}<span class="sep"> • </span><small>{{ APP_VERSION }} — نسخة أولية قيد التطوير. <a href="{% url 'core:complaint' %}">أبلغ عن مشكلة</a></small>{% endif %}</div></div></footer>{% endif %}{% if show_splash %}<section id="splash" class="splash-overlay" role="status" aria-live="polite"><div class="splash-card"><div class="splash-logo-wrap"><img src="{% static 'img/logo.png' %}" srcset="{% static 'img/logo.png' %} 1x, {% static 'img/logo@2x.png' %} 2x" alt="Mutawatir" class="splash-logo"></div><div class="splash-text"><blockquote class="hadith"><span class="qmark">«</span>خيرُكم من تعلَّم القرآن وعلَّمه<span class="qmark">»</span></blockquote><div class="hadith-src">— رواه البخاري</div></div></div></section><script>document.addEventListener('DOMContentLoaded',function(){const s=document.getElementById('splash');if(!s)return;requestAnimationFrame(()=>s.classList.add('show'));setTimeout(()=>{s.classList.add('hide');s.style.pointerEvents='none';setTimeout(()=>s.remove(),420)},1600)});</script>{% endif %}<script>document.addEventListener('click',function(e){const btn=e.target.closest('.btn');if(!btn)return;if(btn.tagName==='A'&&!btn.hasAttribute('data-ripple'))return;if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;const rect=btn.getBoundingClientRect(),size=Math.max(rect.width,rect.height),r=document.createElement('span');r.className='ripple';r.style.position='absolute';r.style.width=r.style.height=size+'px';r.style.left=(e.clientX-rect.left-size/2)+'px';r.style.top=(e.clientY-rect.top-size/2)+'px';btn.appendChild(r);setTimeout(()=>r.remove(),500);},false);(function(){const hud=document.getElementById('score-hud');if(!hud)return;const val=document.getElementById('scoreValue'),d=document.getElementById('scoreDelta'),s=parseInt(hud.getAttribute('data-score')||'0',10),delta=hud.hasAttribute('data-delta')?parseInt(hud.getAttribute('data-delta')||'0',10):0;val.textContent=isNaN(s)?'0':String(s);if(!isNaN(delta)&&delta!==0){d.textContent=(delta>0?'+':'')+delta;d.classList.toggle('pos',delta>0);d.classList.toggle('neg',delta<0);d.hidden=false;requestAnimationFrame(()=>d.classList.add('show'));setTimeout(()=>{d.classList.remove('show');setTimeout(()=>{d.hidden=true},280)},1500);}})();{% if not suppress_toasts %}(function(){const wrap=document.getElementById('toast-root'),src=document.getElementById('server-messages');if(!wrap||!src)return;const levelClass=l=>!l?'toast--info':l.includes('success')?'toast--success':l.includes('error')?'toast--error':l.includes('warning')?'toast--warning':'toast--info';const show=(text,lvl='info',t=3600)=>{const el=document.createElement('div');el.className='toast '+levelClass(lvl);el.innerHTML='<span>'+text+'</span><button class="toast__close" aria-label="إغلاق" title="إغلاق">&times;</button>';wrap.appendChild(el);const close=()=>{el.style.animation='toast-out .18s ease-in forwards';setTimeout(()=>el.remove(),180)};el.querySelector('.toast__close').addEventListener('click',close);setTimeout(close,t)};src.querySelectorAll('div[data-level]').forEach((el,i)=>{const lvl=el.getAttribute('data-level')||'info',text=(el.textContent||'').trim();setTimeout(()=>show(text,lvl),i*350)});})();{% endif %}(function(){const btn=document.getElementById('userMenuBtn'),menu=document.getElementById('userMenu');if(!btn||!menu)return;btn.addEventListener('click',()=>{const open=!menu.hasAttribute('hidden');if(open){menu.setAttribute('hidden','');btn.setAttribute('aria-expanded','false')}else{menu.removeAttribute('hidden');btn.setAttribute('aria-expanded','true')}});document.addEventListener('click',e=>{if(!menu||menu.hasAttribute('hidden'))return;if(!e.target.closest('.user-cluster')){menu.setAttribute('hidden','');btn.setAttribute('aria-expanded','false')}})})();</script></body></html>

# ===== FILE: core/templates/core/complaint.html =====
{% extends "core/base.html" %}
{% load static i18n %}

{% block title %}إبلاغ / اقتراح — متواتر{% endblock %}

{% block content %}
<style>
  .page-shell{min-height:70vh; display:grid; gap:1rem; align-content:start}
  .header-card{
    text-align:center; padding:1.2rem 1rem 1rem;
    border-radius:16px;
    border:1px solid rgba(212,175,55,.22);
    background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    box-shadow: 0 18px 44px rgba(0,0,0,.22);
  }
  .pill{
    display:inline-flex; align-items:center; gap:.5rem;
    direction: rtl; /* الدوت في اليمين */
    font-weight:800; color:#1b1b1b;
    background:linear-gradient(135deg,var(--accent, #f1cf6b), var(--accent-2, #f3e4a8));
    padding:.36rem .7rem; border-radius:999px; border:1px solid rgba(212,175,55,.55);
    margin-bottom:.6rem;
  }
  .pill .dot{
    width:10px;height:10px;border-radius:50%;
    background:#16a34a; box-shadow:0 0 0 6px rgba(22,163,74,.15);
    animation:pulse 1.8s ease-in-out infinite;
  }
  @keyframes pulse{
    0%,100%{ box-shadow:0 0 0 6px rgba(22,163,74,.15) }
    50%{ box-shadow:0 0 0 9px rgba(22,163,74,.30) }
  }
  .title{margin:.1rem 0 .35rem; color:#fff; font-weight:900; font-size:clamp(20px,3.2vw,26px)}
  .subtitle{color:var(--muted); max-width:820px; margin:.1rem auto 0}

  /* Form Card */
  .form-card{
    background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    border:1px solid rgba(255,255,255,.10);
    border-radius:16px; padding:1rem 1.1rem;
    box-shadow:0 14px 36px rgba(0,0,0,.22);
    display:grid; gap:1rem;
  }
  .group-title{margin:0; color:#fff; font-weight:800; font-size:1.05rem}
  .cats{display:flex; flex-wrap:wrap; gap:.5rem; margin-top:.4rem}
  .cat {
    position:relative;
  }
  .cat input{
    position:absolute; inset:0; opacity:0; pointer-events:none;
  }
  .cat label{
    display:inline-flex; align-items:center; gap:.4rem;
    padding:.45rem .7rem; border-radius:999px; cursor:pointer;
    border:1px solid rgba(212,175,55,.35);
    color:#fefefe; background:rgba(255,255,255,.04);
    transition:.15s ease;
    user-select:none;
  }
  .cat label:hover{ filter:brightness(1.06) }
  .cat input:checked + label{
    background:linear-gradient(135deg,var(--accent, #f1cf6b), var(--accent-2, #f3e4a8));
    color:#1b1b1b; border-color:rgba(212,175,55,.65); font-weight:800;
  }

  .field{display:grid; gap:.4rem}
  .field textarea{
    width:100%; min-height:160px; resize:vertical;
    background:rgba(0,0,0,.25); color:#fff; border:1px solid rgba(255,255,255,.12);
    border-radius:12px; padding:.75rem .9rem; line-height:1.7;
  }
  .counter{color:var(--muted); font-size:.9rem; text-align: start;}
  .form-actions{display:flex; gap:.6rem; flex-wrap:wrap; justify-content:flex-start}
  .btn-lg{padding:.8rem 1.15rem; border-radius:12px; font-weight:900}
</style>

<div class="page-shell">

  <!-- Header -->
  <section class="header-card" dir="rtl">
    <div class="pill">
      <span class="dot" aria-hidden="true"></span>
      إبلاغ / اقتراح
    </div>
    <h1 class="title">ساعدنا نحسّن متواتر</h1>
    <p class="subtitle">
        اختر تصنيفًا أو أكثر، ثم اكتب التفاصيل. سنراجع بلاغك بسرعة ونطوّر التجربة باستمرار.
    </p>
  </section>

  <!-- Messages (لو فيه رسائل Django) -->
  {% if messages %}
    <div style="display:grid; gap:.5rem">
      {% for message in messages %}
        <div class="alert {{ message.tags }}">{{ message }}</div>
      {% endfor %}
    </div>
  {% endif %}

  <!-- Form -->
  <section class="form-card" aria-labelledby="form-title">
    <h2 id="form-title" class="group-title">تفاصيل البلاغ / الاقتراح</h2>

    <form method="post" action="{% url 'core:complaint' %}" novalidate>
      {% csrf_token %}

      <!-- Categories -->
      <div class="field">
        <label class="group-title" style="font-size:1rem">التصنيف</label>
        <div class="cats">
          {% for t in types %}
            <div class="cat">
              <input type="checkbox" id="cat{{ forloop.counter }}" name="category" value="{{ t }}">
              <label for="cat{{ forloop.counter }}">{{ t }}</label>
            </div>
          {% endfor %}
        </div>
      </div>

      <!-- Text -->
      <div class="field">
        <label for="complaint-text" class="group-title" style="font-size:1rem">الوصف</label>
        <textarea id="complaint-text" name="text" placeholder="اكتب المشكلة أو الاقتراح بتفاصيل واضحة…"></textarea>
        <div class="counter"><span id="charCount">0</span> حرف</div>
      </div>

      <!-- Actions -->
      <div class="form-actions">
        <button type="submit" class="btn btn-primary btn-lg">إرسال</button>
        <a href="{% url 'core:main_menu' %}" class="btn btn-outline btn-lg">العودة للرئيسية</a>
      </div>
    </form>
  </section>

</div>

<script>
  // عدّاد الحروف البسيط
  (function(){
    var ta = document.getElementById('complaint-text');
    var out = document.getElementById('charCount');
    if (!ta || !out) return;
    var update = function(){ out.textContent = (ta.value || '').length; };
    ta.addEventListener('input', update);
    update();
  })();
</script>
{% endblock %}

# ===== FILE: core/templates/core/complaint_admin.html =====
{% extends 'core/base.html' %}

{% block title %}الشكاوى (للإدارة){% endblock %}

{% block content %}
  <style>
    .admin-card {
      background:#fff;
      border:2px solid var(--primary);
      border-radius:12px;
      padding:1.25rem 1.5rem;
      box-shadow:0 14px 50px rgba(15,95,59,0.1);
      margin-bottom:1.5rem;
    }
    table {
      width:100%;
      border-collapse: collapse;
      margin-top:0.5rem;
    }
    th, td {
      padding:12px 10px;
      text-align: right;
      border-bottom:1px solid #e6e6e6;
      font-size:0.9rem;
    }
    th {
      background: rgba(15,95,59,0.07);
      font-weight:600;
    }
    .status-badge {
      padding:4px 10px;
      border-radius:999px;
      font-size:0.7rem;
      display:inline-block;
    }
    .resolved { background: #d1f0d8; color:#0f5f3b; }
    .unresolved { background: #ffe7d9; color:#a64400; }
    .btn-small {
      padding:6px 12px;
      border-radius:6px;
      border:none;
      cursor:pointer;
      font-size:0.75rem;
      font-weight:600;
      transition: filter .2s;
    }
    .toggle-btn {
      background: var(--primary-light);
      color:#fff;
    }
    .toggle-btn:hover { filter: brightness(1.1); }
  </style>

  <div class="admin-card">
    <h1 style="margin-top:0;">الشكاوى الواردة</h1>
    <p>هنا كل الشكاوى مع اسم الحساب وتفاصيلها. تقدر تغيّر الحالة لتعليم أنها مُعالجة.</p>

    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>اسم العرض</th>
          <th>اسم المستخدم</th>
          <th>نص الشكوى / الاقتراح</th>
          <th>تاريخ الإرسال</th>
          <th>الحالة</th>
          <th>تحكم</th>
        </tr>
      </thead>
      <tbody>
        {% for c in complaints %}
          <tr>
            <td>{{ forloop.counter }}</td>
            <td>{{ c.student.display_name }}</td>
            <td>{{ c.student.user.username }}</td>
            <td style="white-space: pre-wrap;">{{ c.text }}</td>
            <td>{{ c.created_at }}</td>
            <td>
              {% if c.resolved %}
                <span class="status-badge resolved">محلولة</span>
              {% else %}
                <span class="status-badge unresolved">غير محلولة</span>
              {% endif %}
            </td>
            <td>
              <form method="post" style="display:inline;">
                {% csrf_token %}
                <input type="hidden" name="complaint_id" value="{{ c.id }}">
                <input type="hidden" name="action" value="toggle">
                <button type="submit" class="btn-small toggle-btn">
                  {% if c.resolved %}إلغاء الحل{% else %}وضع كمحلولة{% endif %}
                </button>
              </form>
            </td>
          </tr>
        {% empty %}
          <tr><td colspan="7" style="text-align:center;">ما فيش شكاوى واردة حالياً.</td></tr>
        {% endfor %}
      </tbody>
    </table>
    <div style="margin-top:1rem;">
      <a href="{% url 'core:main_menu' %}" class="btn-small" style="background:#f0f0f0; color: #0f5f3b; border:1px solid var(--primary);">العودة إلى القائمة الرئيسية</a>
    </div>
  </div>
{% endblock %}

# ===== FILE: core/templates/core/index.html =====
{% extends 'core/base.html' %}
{% block title %}إدخال الاسم{% endblock %}
{% block content %}
  <h1>مرحباً بك في تطبيق متشابهات القرآن</h1>
  <p>فضلاً أدخل اسمك للمتابعة:</p>
  <form method="post">
    {% csrf_token %}
    <input type="text" name="display_name" placeholder="اسمك"
           required style="padding:0.5rem; margin-bottom:0.5rem; width:100%;">
    <button type="submit">دخول</button>
  </form>
{% endblock %}

# ===== FILE: core/templates/core/landing.html =====
{% extends 'core/base.html' %}
{% load i18n %}

{% block title %}Mutawatir — متواتر{% endblock %}

{% block content %}
<section class="hero home">
  <div class="hero-inner">
    <img src="/static/img/logo.png" alt="Mutawatir" class="logo">
    <h1 class="hero-title">متواتر — Mutawatir</h1>
    <p class="hero-subtitle">منصة متطورة لاختبار وتثبيت حفظ القرآن، وترسيخ صورة المصحف في الذاكرة.</p>
    <div class="cta">
      <a class="btn btn-primary" href="{% url 'core:login' %}">تسجيل الدخول</a>
      <a class="btn btn-outline" href="{% url 'core:signup' %}">إنشاء حساب</a>
    </div>
  </div>
</section>

<section class="card" style="margin-top:1rem">
  <h3>عن متواتر</h3>
  <p>
    "متواتر" هو موقع تفاعلي مبتكر يهدف إلى مساعدة حفظة القرآن الكريم على اختبار وتقوية حفظهم، مع التركيز على الآيات المتشابهة.
    يوفر للمستخدمين اختبارات دقيقة تُبنى على اختيارهم للأجزاء أو الأرباع أو السور، مع عرض النتائج والتقييمات التفصيلية،
    مما يساعدهم على اكتشاف نقاط القوة ومواطن النسيان، وتحسين أدائهم بأسلوب عملي وفعّال.
    كما يساهم في ترسيخ صورة صفحات المصحف في الذاكرة، ليحفظ القارئ القرآن وكأنه يراه أمامه صفحةً صفحة.
  </p>
</section>
{% endblock %}

# ===== FILE: core/templates/core/leaderboard.html =====
{% extends "core/base.html" %}
{% load static i18n %}

{% block title %}لوحة المنافسة — متواتر{% endblock %}

{% block content %}
<style>
  .board-shell{min-height:72vh; display:grid; gap:1rem; align-content:start}
  .head{
    display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:.6rem;
    padding:.9rem 1rem; border-radius:16px;
    background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    border:1px solid rgba(255,255,255,.10); box-shadow:0 14px 36px rgba(0,0,0,.22);
  }
  .head h1{margin:0; color:#fff; font-weight:900}
  .table-wrap{
    overflow:auto;
    background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    border:1px solid rgba(255,255,255,.10); border-radius:16px; box-shadow:0 14px 36px rgba(0,0,0,.22);
  }
  table{width:100%; border-collapse:separate; border-spacing:0}
  thead th{
    text-align:center; color:#e7efe9; font-weight:900; padding:.75rem .6rem; position:sticky; top:0; background:#071510;
  }
  tbody td{padding:.65rem .6rem; border-top:1px solid rgba(255,255,255,.07); text-align:center; color:#e9f5ef}
  tbody tr:nth-child(odd){background:rgba(255,255,255,.02)}
  .player{
    display:flex; gap:.55rem; align-items:center; justify-content:flex-start; color:#fff; font-weight:800;
  }
  .avatar{width:30px; height:30px; border-radius:50%; overflow:hidden; background:#0b1713; display:inline-grid; place-items:center; border:1px solid rgba(255,255,255,.12)}
  .avatar img{width:100%; height:100%; object-fit:cover}
  .rank{
    font-weight:900; width:2.8rem; text-align:center; border-radius:999px; padding:.25rem .45rem; margin-inline:auto;
    background:#0b1713; border:1px solid rgba(255,255,255,.12); color:#fff;
  }
  .r1{background:linear-gradient(135deg,#ffe08a,#e7b200); color:#1b1b1b}
  .r2{background:linear-gradient(135deg,#e6e9ef,#9aa3b2); color:#1b1b1b}
  .r3{background:linear-gradient(135deg,#ffd2a6,#b66a28); color:#1b1b1b}
  .badge{margin-inline-start:.35rem}
  .t-center{text-align:center}
</style>

<div class="board-shell">
  <div class="head">
    <h1>لوحة المنافسة</h1>
    <div class="actions">
      <a href="{% url 'core:main_menu' %}" class="btn btn-outline">الرجوع للرئيسية</a>
    </div>
  </div>

  <div class="table-wrap">
    <table dir="rtl">
      <thead>
        <tr>
          <th>#</th>
          <th>الطالب</th>
          <th>النقاط</th>
          <th>الامتحانات</th>
          <th>صحيح</th>
          <th>خطأ</th>
          <th>غير مُجاب</th>
          <th>الدقة</th>
        </tr>
      </thead>
      <tbody>
        {% for r in rows %}
        <tr>
          <td>
            <span class="rank {% if r.rank == 1 %}r1{% elif r.rank == 2 %}r2{% elif r.rank == 3 %}r3{% endif %}">
              {{ r.rank }}
            </span>
          </td>
          <td>
            <span class="player">
              <span class="avatar">
                {% if r.avatar %}<img src="{{ r.avatar }}" alt="">{% else %}<span class="fallback">👤</span>{% endif %}
              </span>
              {{ r.display_name }}
              {% if r.rank <= 3 %}
                <span class="badge">{% if r.rank == 1 %}🥇{% elif r.rank == 2 %}🥈{% else %}🥉{% endif %}</span>
              {% endif %}
            </span>
          </td>
          <td><b>{{ r.score }}</b></td>
          <td>{{ r.exams }}</td>
          <td>{{ r.correct }}</td>
          <td>{{ r.wrong }}</td>
          <td>{{ r.unanswered }}</td>
          <td class="t-center">
            {% if r.acc_percent is not None %}{{ r.acc_percent|floatformat:2 }}%{% else %}—{% endif %}
          </td>
        </tr>
        {% empty %}
        <tr><td colspan="8" class="t-center">لا توجد بيانات بعد.</td></tr>
        {% endfor %}
      </tbody>
    </table>
  </div>
</div>
{% endblock %}

# ===== FILE: core/templates/core/login.html =====
{% extends "core/base.html" %}
{% load static i18n %}

{% block title %}تسجيل الدخول — متواتر{% endblock %}

{% block content %}
<style>
  .auth-shell{
    min-height: 72vh;
    display: grid;
    place-items: center;
  }
  .auth-card{
    width: 100%;
    max-width: 420px;
    background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    border: 1px solid rgba(255,255,255,.10);
    border-radius: 16px;
    box-shadow: 0 18px 48px rgba(0,0,0,.28);
    padding: 1.1rem 1.15rem;
  }
  .auth-title{margin: .25rem 0 .9rem; color: #fff; font-weight: 900; letter-spacing: .2px; text-align:center}
  .auth-lead{margin: -.35rem 0 1rem; color: var(--muted); text-align:center}

  .form-control{display:grid; gap:.35rem; margin:.55rem 0}
  .form-control label{font-weight:800; color:#f1f6f3}
  .input{width:100%; background:#09130f; border:1px solid rgba(255,255,255,.16); color:var(--text); border-radius:12px; padding:.7rem .85rem}
  .input::placeholder{color:#dbe7e1; opacity:.9}

  .pwd-wrap{position:relative}
  .input.has-eye{padding-left: 2.3rem;}
  .eye-toggle{
    position:absolute; left:.45rem; top:50%; transform: translateY(-50%);
    display:grid; place-items:center;
    width: 28px; height: 28px;
    border: 1px solid rgba(255,255,255,.16);
    background:#0a1713; color: var(--text);
    border-radius: 8px; cursor: pointer;
  }
  .eye-toggle svg{width:18px; height:18px; display:block}
  .eye-toggle .icon-off{display:none}
  .eye-toggle[aria-pressed="true"] .icon-on{display:none}
  .eye-toggle[aria-pressed="true"] .icon-off{display:block}

  .auth-actions{display:flex; gap:.6rem; align-items:center; justify-content:center; margin-top: .9rem}
  .auth-links{display:flex; gap:.5rem; flex-wrap:wrap}
  .auth-links a{color:var(--accent); font-weight:800}
  .hint{ color:var(--muted); font-size:.92rem }
</style>

<div class="auth-shell">
  <div class="auth-card">
    <h1 class="auth-title">تسجيل الدخول</h1>
    <p class="auth-lead">ادخل بياناتك للمتابعة.</p>

    <form method="post" action="{% url 'core:login' %}">
      {% csrf_token %}
      <div class="form-control">
        <label for="id_username">اسم المستخدم / البريد الإلكتروني</label>
        <input id="id_username" name="username" class="input" placeholder="username أو email" required autofocus>
        <div class="hint">يمكنك إدخال اسم المستخدم أو بريدك الإلكتروني.</div>
      </div>

      <div class="form-control">
        <label for="id_password">كلمة المرور</label>
        <div class="pwd-wrap">
          <input id="id_password" name="password" type="password" class="input has-eye" placeholder="••••••••" required>
          <button type="button" id="togglePwd" class="eye-toggle" aria-label="إظهار كلمة المرور" aria-pressed="false">
            <!-- عين -->
            <svg class="icon-on" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z" stroke="currentColor" stroke-width="2"/>
              <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
            </svg>
            <!-- عين متشطّبة -->
            <svg class="icon-off" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M3 3l18 18" stroke="currentColor" stroke-width="2"/>
              <path d="M2 12s3.5-6 10-6c-2.3 0-4.2.7-5.7 1.7M22 12s-3.5 6-10 6c-2.3 0-4.2-.7-5.7-1.7" stroke="currentColor" stroke-width="2"/>
              <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="auth-actions">
        <button class="btn btn-primary" type="submit">تسجيل الدخول</button>
      </div>

      <div class="auth-actions">
        <div class="auth-links">
          <a href="{% url 'core:signup' %}">ليس لديك حساب؟ أنشئ حسابًا</a>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
  (function(){
    const btn = document.getElementById('togglePwd');
    const input = document.getElementById('id_password');
    if(btn && input){
      btn.addEventListener('click', ()=>{
        const show = input.getAttribute('type') === 'password';
        input.setAttribute('type', show ? 'text' : 'password');
        btn.setAttribute('aria-pressed', show ? 'true' : 'false');
        btn.setAttribute('aria-label', show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
      });
    }
  })();
</script>
{% endblock %}

# ===== FILE: core/templates/core/main_menu.html =====
{% extends "core/base.html" %}
{% load static i18n %}

{% block title %}الرئيسية — متواتر{% endblock %}

{% if IS_ALPHA %}
<div id="alpha-banner" class="alpha-banner" role="status">
  هذه نسخة <strong>{{ APP_VERSION }}</strong> — ما زلنا نُحسّن التجربة. لو قابلتك مشكلة
  <a href="{% url 'core:complaint' %}">بلغّنا من هنا</a>.
  <button id="alpha-dismiss" type="button" aria-label="إغلاق">×</button>
</div>
{% endif %}

{% block content %}
<style>
  /* إخفاء تحية النافبار في صفحة الهوم فقط */
  .nav-welcome, #nav-welcome, .top-welcome { display:none !important; }

  .home-shell{min-height:72vh; display:grid; align-content:start; gap:1.2rem}
  .welcome{
    text-align:center;
    padding:1.4rem 1rem 1rem;
    border-radius:16px;
    border:1px solid rgba(212,175,55,.22);
    background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    box-shadow: 0 18px 44px rgba(0,0,0,.22);
  }
  .welcome h1{
    margin:.2rem 0 .5rem; color:#fff; font-weight:900; letter-spacing:.2px; font-size:clamp(20px,3.2vw,26px)
  }
  .welcome .lead{ color:var(--muted); max-width:820px; margin:.2rem auto 0; }

  .chip{
    display:inline-flex;align-items:center;gap:.45rem;
    direction: rtl; /* الدوت في اليمين */
    font-weight:800; color:#1b1b1b;
    background:linear-gradient(135deg,var(--accent),var(--accent-2));
    padding:.38rem .7rem; border-radius:999px; border:1px solid rgba(212,175,55,.55);
  }
  .chip .dot{
    width:10px;height:10px;border-radius:50%;
    background:#16a34a; /* أخضر */
    box-shadow:0 0 0 6px rgba(22,163,74,.15);
    animation:pulse 1.8s ease-in-out infinite;
  }
  @keyframes pulse{
    0%,100%{ box-shadow:0 0 0 6px rgba(22,163,74,.15) }
    50%{ box-shadow:0 0 0 9px rgba(22,163,74,.30) }
  }
  .badge-medal{margin-inline-start:.4rem; font-weight:900}

  .home-cta{display:flex; gap:.6rem; justify-content:center; flex-wrap:wrap; margin-top:1rem}
  .btn-lg{padding:.8rem 1.15rem; border-radius:12px; font-weight:900}

  .grid-cards{display:grid; grid-template-columns:repeat(3,1fr); gap:.9rem}
  @media (max-width: 900px){ .grid-cards{grid-template-columns:1fr} }
  .cardx{
    position:relative;
    background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    border:1px solid rgba(255,255,255,.10);
    border-radius:16px; padding:1.1rem 1.15rem;
    box-shadow:0 14px 36px rgba(0,0,0,.22);
    display:grid; gap:.5rem;
  }
  .cardx h3{margin:0; color:#fff; font-weight:900}
  .cardx p{margin:0; color:var(--muted)}
  .cardx .go{justify-self:start; margin-top:.35rem}

  /* إحصائيات */
  .stats-grid{
    display:grid; grid-template-columns:repeat(4,1fr); gap:.6rem; margin:.2rem 0 .4rem;
  }
  @media(max-width:700px){ .stats-grid{grid-template-columns:repeat(2,1fr)} }
  .stat{
    background:#0f1118; border:1px solid rgba(255,255,255,.10);
    border-radius:14px; padding:.65rem .7rem; text-align:center;
    box-shadow:0 10px 28px rgba(0,0,0,.20);
  }
  .stat .num{display:block; font-weight:900; font-size:clamp(18px,4vw,24px); color:#fff}
  .stat .lbl{display:block; font-weight:800; color:#9aa3b2; margin-top:.15rem; font-size:.95rem}

  .title-underline{
    height:2px; background:linear-gradient(90deg, transparent, var(--accent), transparent);
    border-radius:2px; margin:.35rem auto 0; width:180px; opacity:.65;
  }

  .about{
    margin-top:1rem;
    background:linear-gradient(135deg, #fff8ec22, #f3efe622);
    border-inline-start:6px solid var(--accent);
    padding: .8rem 1rem; border-radius:12px;
    box-shadow:0 10px 30px rgba(212,175,55,.15);
  }
  .about .title{margin:.1rem 0 .4rem; color:#fff; font-weight:900}
  .about p{margin:0; color:#e9f5ef}
</style>

<div class="home-shell">

  <section class="welcome">
    <!-- بادج الترحيب (الدوت في اليمين) -->
    <div class="chip" style="margin-bottom:.55rem">
      <span class="dot" aria-hidden="true"></span>
      مرحبًا، {{ student.display_name|default:request.user.username }}
      {% if my_rank and my_rank|add:0 <= 3 %}
        <span class="badge-medal">
          {% if my_rank == 1 %}🥇{% elif my_rank == 2 %}🥈{% else %}🥉{% endif %} #{{ my_rank }}
        </span>
      {% endif %}
    </div>

    <h1>متواتر — <span style="color:var(--accent)">Mutawatir</span></h1>
    <div class="title-underline"></div>
    <p class="lead">
      منصة متطورة لاختبار وتثبيت حفظ القرآن، وترسيخ صورة المصحف في الذاكرة.
    </p>

    <div class="home-cta">
      <!-- تم تغيير الوجهة إلى كتالوج الاختبارات -->
      <a href="/tests/" class="btn btn-primary btn-lg">بدء اختبار جديد</a>
      {% if request.session.questions %}
        <a href="{% url 'core:test_question' %}" class="btn btn-outline btn-lg">استكمال الاختبار الحالي</a>
      {% endif %}
      <a href="{% url 'core:complaint' %}" class="btn btn-outline btn-lg">إبلاغ / اقتراح</a>
    </div>
  </section>

<section class="grid-cards" aria-label="الأقسام الرئيسية">
  <article class="cardx">
    <h3>اختبارات الحفظ</h3>
    <p>اختر نوع الاختبار ثم حدّد نطاقك (الأجزاء/الأرباع/السور) وابدأ.</p>
    <!-- تم تغيير الوجهة إلى كتالوج الاختبارات -->
    <a href="/tests/" class="btn btn-primary go">ابدأ الآن</a>
  </article>

  <article class="cardx">
    <h3>الإبلاغ والملاحظات</h3>
    <p>واجهت مشكلة أو عندك اقتراح لتحسين التجربة؟ شاركنا رأيك لنحسّن المنصة باستمرار.</p>
    <a href="{% url 'core:complaint' %}" class="btn btn-outline go">إرسال ملاحظة</a>
  </article>

  <!-- إحصائياتك (ستايل مماثل لصفحة /stats/) -->
  <article class="cardx">
    <h3>إحصائياتك</h3>

    <style>
      .stats-tiles{
        display:grid;
        grid-template-columns:repeat(4,1fr);
        gap:.6rem;
        margin:.4rem 0 .6rem;
      }
      @media(max-width:700px){ .stats-tiles{grid-template-columns:repeat(2,1fr)} }
      .tile{
        background:#0b0f16;
        border:1px solid rgba(255,255,255,.10);
        border-radius:14px;
        padding:.8rem .9rem;
        text-align:center;
        box-shadow:0 10px 28px rgba(0,0,0,.18);
      }
      .tile .v{display:block; font-weight:900; font-size:clamp(22px,4.6vw,28px); color:#fff}
      .tile .k{display:block; font-weight:800; color:#9aa3b2; margin-top:.2rem; font-size:.95rem}
    </style>

    <div class="stats-tiles">
      <div class="tile"><span class="v">{{ stats.exams }}</span><span class="k">امتحانات</span></div>
      <div class="tile"><span class="v">{{ stats.correct }}</span><span class="k">صحيح</span></div>
      <div class="tile"><span class="v">{{ stats.wrong }}</span><span class="k">خطأ</span></div>
      <div class="tile"><span class="v">{{ stats.unanswered }}</span><span class="k">غير مُجاب</span></div>
    </div>

    <a href="{% url 'core:stats' %}" class="btn btn-outline go">عرض تفصيلي</a>
  </article>
</section>


    <!-- حسابك -->
    <article class="cardx">
      <h3>حسابك</h3>
      <p>اسم العرض: <strong>{{ student.display_name|default:request.user.username }}</strong></p>
      {% if request.user.email %}
        <p>البريد: <strong>{{ request.user.email }}</strong></p>
      {% endif %}
      <div style="display:flex; gap:.5rem; flex-wrap:wrap; margin-top:.35rem">
        <a href="{% url 'core:account_settings' %}" class="btn btn-primary">تعديل معلومات الحساب</a>
        <a href="{% url 'core:logout' %}" class="btn btn-outline">تسجيل الخروج</a>
        {% if request.session.questions %}
          <a href="{% url 'core:test_question' %}" class="btn btn-outline">متابعة الاختبار</a>
        {% endif %}
      </div>
    </article>

    <!-- كارت اللوحة -->
    <article class="cardx">
      <h3>لوحة المنافسة</h3>
      <p>شاهد ترتيب الطلاب حسب الأداء والنشاط.</p>
      {% if my_rank %}<p>ترتيبك الحالي: <b>#{{ my_rank }}</b></p>{% endif %}
      <a href="{% url 'core:leaderboard' %}" class="btn btn-primary go">فتح اللوحة</a>
    </article>
  </section>

  <section class="about" aria-labelledby="about-title">
    <h2 id="about-title" class="title">عن متواتر</h2>
    <p>
      "متواتر" هو موقع تفاعلي مبتكر يهدف إلى مساعدة حفظة القرآن الكريم على اختبار وتقوية حفظهم،
      مع التركيز على الآيات المتشابهة. يوفر للمستخدمين اختبارات دقيقة تُبنى على اختيارهم للأجزاء أو الأرباع أو السور،
      مع عرض النتائج والتقييمات التفصيلية، مما يساعد على التثبيت وترسيخ صورة المصحف في الذاكرة.
    </p>
  </section>

</div>

<!-- إخفاء أي "مرحب" في الهيدر بجوار "تسجيل الخروج" على هذه الصفحة فقط -->
<script>
  document.addEventListener('DOMContentLoaded', function(){
    function hideNavWelcome(){
      var containers = document.querySelectorAll('header, nav, .navbar, .topbar, .site-header');
      containers.forEach(function(h){
        var hasLogout = /(تسجيل الخروج|Log ?out)/.test((h.textContent||'')); if(!hasLogout) return;
        h.querySelectorAll('*').forEach(function(el){
          if(el.children.length===0){
            var t=(el.textContent||'').trim();
            if(/مرحب/.test(t)){ el.style.display='none'; }
          }
        });
      });
    }
    hideNavWelcome();
    new MutationObserver(hideNavWelcome).observe(document.body,{subtree:true,childList:true});
  });
</script>
{% endblock %}

# ===== FILE: core/templates/core/report_done.html =====
<div style="padding:.75rem 1rem; background:#0f1d17; color:#e9f5ef; font-weight:700; border-radius:10px; border:1px solid rgba(255,255,255,.12)">
  تم إرسال البلاغ، شكرًا لك.
</div>

# ===== FILE: core/templates/core/signup.html =====
{% extends "core/base.html" %}
{% load static i18n %}

{% block title %}إنشاء حساب — متواتر{% endblock %}

{% block content %}
<style>
  .auth-shell{
    min-height: 72vh;
    display: grid;
    place-items: center;
  }
  .auth-card{
    width: 100%;
    max-width: 460px;
    background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    border: 1px solid rgba(255,255,255,.10);
    border-radius: 16px;
    box-shadow: 0 18px 48px rgba(0,0,0,.28);
    padding: 1.1rem 1.15rem;
  }
  .auth-title{margin: .25rem 0 .9rem; color: #fff; font-weight: 900; letter-spacing: .2px; text-align:center}
  .auth-lead{margin: -.35rem 0 1rem; color: var(--muted); text-align:center}

  .form-control{display:grid; gap:.35rem; margin:.55rem 0}
  .form-control label{font-weight:800; color:#f1f6f3}
  .input{width:100%; background:#09130f; border:1px solid rgba(255,255,255,.16); color:var(--text); border-radius:12px; padding:.7rem .85rem}
  .input::placeholder{color:#dbe7e1; opacity:.9}

  .pwd-wrap{position:relative}
  .input.has-eye{padding-left: 2.3rem;}
  .eye-toggle{
    position:absolute; left:.45rem; top:50%; transform: translateY(-50%);
    display:grid; place-items:center;
    width: 28px; height: 28px;
    border: 1px solid rgba(255,255,255,.16);
    background:#0a1713; color: var(--text);
    border-radius: 8px; cursor: pointer;
  }
  .eye-toggle svg{width:18px; height:18px; display:block}
  .eye-toggle .icon-off{display:none}
  .eye-toggle[aria-pressed="true"] .icon-on{display:none}
  .eye-toggle[aria-pressed="true"] .icon-off{display:block}

  .hint{font-size:.9rem; color:var(--muted)}
  .auth-actions{display:flex; gap:.6rem; align-items:center; justify-content:center; margin-top: .9rem}
  .auth-links{display:flex; gap:.5rem; flex-wrap:wrap}
  .auth-links a{color:var(--accent); font-weight:800}
</style>

<div class="auth-shell">
  <div class="auth-card">
    <h1 class="auth-title">إنشاء حساب</h1>
    <p class="auth-lead">املأ البيانات التالية لبدء رحلتك.</p>

    <form method="post" action="{% url 'core:signup' %}">
      {% csrf_token %}
      <div class="form-control">
        <label for="id_student_name">اسم الطالب</label>
        <input id="id_student_name" name="student_name" class="input" placeholder="مثال: أحمد حافظ" required autofocus>
        <div class="hint">سيتم إنشاء اسم مستخدم تلقائيًا من الاسم (بالأحرف اللاتينية والشرطة السفلية).</div>
      </div>

      <div class="form-control">
        <label for="id_password">كلمة المرور</label>
        <div class="pwd-wrap">
          <input id="id_password" name="password" type="password"
                 class="input has-eye"
                 placeholder="على الأقل 8 أحرف وتحتوي أحرفًا وأرقامًا"
                 minlength="8"
                 pattern="(?=.*[A-Za-z])(?=.*\d).{8,}"
                 title="8 أحرف على الأقل وتحتوي على أحرف وأرقام"
                 required>
          <button type="button" id="togglePwd" class="eye-toggle" aria-label="إظهار كلمة المرور" aria-pressed="false">
            <!-- عين -->
            <svg class="icon-on" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z" stroke="currentColor" stroke-width="2"/>
              <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
            </svg>
            <!-- عين متشطّبة -->
            <svg class="icon-off" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M3 3l18 18" stroke="currentColor" stroke-width="2"/>
              <path d="M2 12s3.5-6 10-6c-2.3 0-4.2.7-5.7 1.7M22 12s-3.5 6-10 6c-2.3 0-4.2-.7-5.7-1.7" stroke="currentColor" stroke-width="2"/>
              <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
            </svg>
          </button>
        </div>
        <div class="hint">يجب ألا تقل عن 8 أحرف وتحتوي على أحرف وأرقام.</div>
      </div>

      <div class="auth-actions">
        <button class="btn btn-primary" type="submit">إنشاء الحساب</button>
      </div>

      <div class="auth-actions">
        <div class="auth-links">
          <a href="{% url 'core:login' %}">لديك حساب؟ سجّل دخول</a>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
  (function(){
    const btn = document.getElementById('togglePwd');
    const input = document.getElementById('id_password');
    if(btn && input){
      btn.addEventListener('click', ()=>{
        const show = input.getAttribute('type') === 'password';
        input.setAttribute('type', show ? 'text' : 'password');
        btn.setAttribute('aria-pressed', show ? 'true' : 'false');
        btn.setAttribute('aria-label', show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
      });
    }
  })();
</script>
{% endblock %}

# ===== FILE: core/templates/core/stats.html =====
{% extends "core/base.html" %}
{% load static i18n arabic_extras %}

{% block title %}إحصائياتك — متواتر{% endblock %}

{% block content %}
<style>
  .s-wrap{max-width:980px; margin:18px auto; padding:14px; color:#fff}
  .s-head{
    border:1px solid rgba(212,175,55,.22);
    background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    border-radius:16px; box-shadow:0 14px 36px rgba(0,0,0,.22);
    padding:14px 16px; display:grid; gap:8px;
  }
  .s-title{margin:0; font-weight:900}
  .s-grid{display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-top:6px}
  @media (max-width:900px){ .s-grid{grid-template-columns:repeat(2,1fr)} }
  @media (max-width:540px){ .s-grid{grid-template-columns:1fr} }
  .card{
    background:#0f1118; border:1px solid rgba(255,255,255,.10);
    border-radius:14px; padding:12px; display:grid; gap:4px; text-align:center
  }
  .num{ font-size:1.6rem; font-weight:900 }
  .lbl{ color:#c8d1cf; font-weight:800 }
  .ok .num{ color:#22c55e } .no .num{ color:#ef4444 } .muted .num{ color:#e5d18f }

  .s-actions{display:flex; gap:.6rem; margin-top:10px; flex-wrap:wrap}
</style>

<div class="s-wrap" dir="rtl">
  <header class="s-head">
    <h1 class="s-title">إحصائياتك</h1>
    <div class="s-grid">
      <div class="card muted">
        <div class="num">{{ stats.exams|arabic_digits }}</div>
        <div class="lbl">الاختبارات المُنجزة</div>
      </div>
      <div class="card ok">
        <div class="num">{{ stats.correct|arabic_digits }}</div>
        <div class="lbl">إجابات صحيحة</div>
      </div>
      <div class="card no">
        <div class="num">{{ stats.wrong|arabic_digits }}</div>
        <div class="lbl">إجابات خاطئة</div>
      </div>
      <div class="card">
        <div class="num">{{ stats.unanswered|arabic_digits }}</div>
        <div class="lbl">غير مُجاب</div>
      </div>
    </div>

    <div class="s-actions">
      <a href="{% url 'core:test_selection' %}" class="btn btn-primary">بدء اختبار جديد</a>
      <a href="{% url 'core:main_menu' %}" class="btn btn-outline">الرجوع للرئيسية</a>
    </div>
  </header>
</div>
{% endblock %}

# ===== FILE: core/templates/core/test_catalog.html =====
{% extends "core/base.html" %}
{% load static i18n %}

{% block title %}كتالوج الاختبارات — متواتر{% endblock %}

{% block content %}
<style>
  .catalog { min-height:66vh; display:grid; gap:1rem; align-content:start; }
  .head { text-align:center; padding:.8rem 0 .4rem; }
  .head h1 { margin:.2rem 0 .3rem; color:#fff; font-weight:900; font-size:clamp(20px,3.2vw,26px); }
  .head p  { color:var(--muted); margin:0 auto; max-width:820px; }

  .tests-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:.9rem; }
  @media (max-width: 900px){ .tests-grid{ grid-template-columns:1fr } }

  .test-card{
    position:relative; border:1px solid rgba(255,255,255,.10); border-radius:16px;
    background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
    box-shadow:0 14px 36px rgba(0,0,0,.22); padding:1rem 1.15rem; display:grid; gap:.4rem;
  }
  .test-card h3{ margin:0; color:#fff; font-weight:900; }
  .test-card p { margin:0; color:var(--muted); min-height:3.2em; }
  .test-card .go{ justify-self:start; margin-top:.5rem }

  .test-card.disabled{ opacity:.55; filter:grayscale(.25); }
  .test-card.disabled .soon{
    position:absolute; top:.8rem; inset-inline-end:.8rem;
    font-size:.8rem; padding:.15rem .45rem; border-radius:999px;
    border:1px solid #d9b44a; background:#fffbea; color:#8a6d1d;
  }

  .backline{ text-align:center; margin-top:.4rem }
</style>

<div class="catalog">
  <div class="head">
    <h1>اختر نوع الاختبار</h1>
    <p>اختر نوع الاختبار الذي يناسب حفظك وإتقانك:</p>
  </div>

  <section class="tests-grid" aria-label="أنواع الاختبارات">
    {% for t in tests %}
      {% if t.available %}
        <article class="test-card">
          <h3>{{ t.title }}</h3>
          <p>{{ t.desc }}</p>
          {% if t.url %}
            <a href="{{ t.url }}" class="btn btn-primary go">اختيار هذا الاختبار</a>
          {% else %}
            <a href="{% url 'core:test_selection' %}?type={{ t.key }}" class="btn btn-primary go">اختيار هذا الاختبار</a>
          {% endif %}
        </article>
      {% else %}
        <article class="test-card disabled" aria-disabled="true">
          <span class="soon">قريبًا</span>
          <h3>{{ t.title }}</h3>
          <p>{{ t.desc }}</p>
          <button class="btn btn-outline go" disabled>غير متاح الآن</button>
        </article>
      {% endif %}
    {% endfor %}
  </section>

  <div class="backline">
    <a href="{% url 'core:main_menu' %}" class="btn btn-outline">عودة للرئيسية</a>
  </div>
</div>
{% endblock %}

# ===== FILE: core/templates/core/test_question.html =====
{% extends "core/base.html" %}{% load static arabic_extras highlight %}
{% block title %}الاختبار — سؤال {{ question_number|arabic_digits }}{% endblock %}

{% block content %}
<div class="q-wrapper" dir="rtl">
  <div id="toast" class="toast" aria-live="polite" aria-atomic="true"></div>

  <header class="q-header">
    <div class="q-scope">{{ scope_label }}</div>
    <div class="q-top">
      <div class="q-counter">
        سؤال <strong>{{ question_number|arabic_digits }}</strong>
        من <strong>{{ total_questions|arabic_digits }}</strong>
      </div>

      <div class="q-head-actions">
        <button type="button" class="btn btn-ghost" id="endBtn" aria-label="إنهاء الاختبار الآن">
          إنهاء الاختبار
        </button>
      </div>
    </div>
  </header>

  <main class="q-main">
    <article class="q-card">
      <h1 class="q-phrase" aria-live="polite">{{ phrase }}</h1>
    </article>

    <form id="answerForm" method="post" class="q-form">{% csrf_token %}
      <fieldset class="q-options">
        {% for opt in options %}
          <label class="q-option">
            <input type="radio" name="occurrence" value="{{ opt }}" required>
            <span class="q-pill">{{ opt|arabic_digits }}</span>
          </label>
        {% endfor %}
      </fieldset>

      <div id="feedback" class="q-feedback" hidden></div>
      <div class="q-actions">
        <button type="submit" class="btn btn-primary" id="nextBtn">تحقّق</button>
      </div>
    </form>

    <details class="q-report">
      <summary>الإبلاغ عن مشكلة في هذا السؤال</summary>
      <form id="reportForm" method="post" action="{% url 'core:report_question' %}" class="q-report-form">
        {% csrf_token %}
        <input type="hidden" name="phrase" value="{{ phrase }}">
        <input type="hidden" name="question_number" value="{{ question_number }}">
        <input type="hidden" name="given" id="givenField" value="">
        <input type="hidden" name="correct" value="{{ correct_count }}">
        <input type="hidden" name="from" value="test">
        <label for="repText" class="q-label">وصف المشكلة</label>
        <textarea id="repText" name="text" rows="3" placeholder="اكتب وصفًا مختصرًا للمشكلة…"></textarea>
        <button type="submit" class="btn btn-danger">إرسال الإبلاغ</button>
      </form>
    </details>

    <form id="endForm" method="post" style="display:none;">
      {% csrf_token %}
      <input type="hidden" name="action" value="end">
    </form>
  </main>
</div>

<div class="q-modal" id="endModal" aria-hidden="true" role="dialog" aria-labelledby="endTitle">
  <div class="q-modal-card">
    <h3 id="endTitle" class="q-modal-title">إنهاء الاختبار؟</h3>
    <p class="q-modal-text">هل تريد إنهاء الاختبار الآن؟ سيتم عرض نتيجتك حتى هذه اللحظة.</p>
    <div class="q-modal-actions">
      <button type="button" class="btn btn-primary" id="confirmEnd">تأكيد الإنهاء</button>
      <button type="button" class="btn btn-ghost" id="cancelEnd">إلغاء</button>
    </div>
  </div>
</div>

<style>
:root{--q-bg:#0f0f15;--q-card:#11131d;--q-text:#f3f4f6;--q-sub:#9aa3b2;--q-gold:#d4af37;--q-gold-2:#b88900;--q-ring:rgba(212,175,55,.35);--q-danger:#ef4444;--q-ghost:#2a3040;--q-radius:16px;--q-shadow:0 10px 30px rgba(0,0,0,.35)}
.q-wrapper{max-width:900px;margin:24px auto;padding:16px;color:var(--q-text)}
.q-header{margin-bottom:16px}
.q-scope{color:var(--q-sub);font-size:14px;margin-bottom:8px}
.q-top{display:grid;gap:10px}
.q-counter{font-size:15px}
.q-head-actions{display:flex;justify-content:flex-end}
.q-main{display:grid;gap:16px}
.q-card{background:linear-gradient(180deg,#0f1118,#11131d);border:1px solid rgba(212,175,55,.2);border-radius:var(--q-radius);box-shadow:var(--q-shadow);padding:18px 20px}
.q-phrase{margin:0;line-height:2.1;font-size:clamp(18px,2.3vw,22px);text-align:center}
.q-form{display:grid;gap:16px}
.q-options{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;border:0;padding:0;margin:0}
@media (max-width:720px){.q-options{grid-template-columns:repeat(2,minmax(0,1fr))}}
.q-option{position:relative;display:block;cursor:pointer}
.q-option input{position:absolute;inset:0;opacity:0;pointer-events:none}
.q-pill{display:grid;place-items:center;height:56px;border-radius:14px;background:#0f1118;border:1px solid rgba(212,175,55,.25);font-size:18px;font-weight:800;letter-spacing:.2px;transition:transform .12s,box-shadow .12s,border-color .12s,background .12s}
.q-option:hover .q-pill{transform:translateY(-1px);box-shadow:0 8px 18px rgba(0,0,0,.25)}
.q-option input:focus-visible+.q-pill{outline:2px solid var(--q-ring);outline-offset:2px}
.q-option input:checked+.q-pill{background:linear-gradient(180deg,rgba(212,175,55,.12),rgba(212,175,55,.08));border-color:var(--q-gold);box-shadow:0 0 0 3px var(--q-ring),0 10px 22px rgba(212,175,55,.15)}
.q-option.correct .q-pill{background:linear-gradient(180deg,rgba(34,197,94,.14),rgba(34,197,94,.08));border-color:#22c55e}
.q-option.wrong .q-pill{background:linear-gradient(180deg,rgba(239,68,68,.14),rgba(239,68,68,.08));border-color:#ef4444}
.q-feedback{text-align:center;padding:10px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:#0f1118;color:var(--q-text);font-weight:700}
.q-feedback.ok{border-color:#22c55e}
.q-feedback.err{border-color:#ef4444}
.q-actions{display:flex;gap:10px;justify-content:center}
.btn{appearance:none;border:0;border-radius:12px;padding:12px 18px;font-weight:800;cursor:pointer;transition:filter .12s,transform .08s}
.btn:active{transform:translateY(1px)}
.btn-primary{background:linear-gradient(180deg,var(--q-gold),var(--q-gold-2));color:#1a1200;border:1px solid rgba(212,175,55,.55)}
.btn-primary:hover{filter:brightness(1.03)}
.btn-ghost{background:#0f1118;color:#q-text;border:1px solid var(--q-ghost)}
.btn-danger{background:#ef4444;color:#310b0b}
.q-report{background:#0f1118;border:1px dashed rgba(212,175,55,.35);border-radius:var(--q-radius);padding:12px 14px}
.q-report>summary{cursor:pointer;font-weight:800;color:var(--q-sub)}
.q-report-form{display:grid;gap:10px;margin-top:10px}
.q-label{font-size:13px;color:var(--q-sub)}
.q-report-form textarea{width:100%;border-radius:10px;padding:10px;background:#0f0f15;color:#1f2937;border:1px solid rgba(255,255,255,.08)}
.toast{position:fixed;inset-inline:16px;bottom:16px;z-index:50;display:none;padding:10px 12px;border-radius:12px;font-weight:700;background:#0f1118;color:#f3f4f6;border:1px solid rgba(212,175,55,.4);box-shadow:0 10px 30px rgba(0,0,0,.35)}
.toast.show{display:inline-block;animation:fadein .2s ease,fadeout .2s ease 2.8s forwards}
@keyframes fadein{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeout{to{opacity:0;transform:translateY(6px)}}
.q-modal{position:fixed;inset:0;display:none;place-items:center;z-index:60;background:#000}
.q-modal.show{display:grid}
.q-modal-card{width:min(520px,92vw);border:1px solid rgba(212,175,55,.35);background:#0f1118;border-radius:16px;padding:1rem 1.1rem;box-shadow:0 24px 60px rgba(0,0,0,.6);display:grid;gap:.6rem}
.q-modal-title{margin:0;color:#fff;font-weight:900;font-size:1.1rem}
.q-modal-actions{display:flex;gap:.6rem;justify-content:flex-start;flex-wrap:wrap}
.q-modal-text{color:var(--q-sub);margin:.2rem 0 .4rem}
</style>

<script>
(function(){
  const form=document.getElementById('answerForm'),
        nextBtn=document.getElementById('nextBtn'),
        endBtn=document.getElementById('endBtn'),
        endForm=document.getElementById('endForm'),
        givenField=document.getElementById('givenField'),
        reportForm=document.getElementById('reportForm'),
        toast=document.getElementById('toast'),
        feedbackBox=document.getElementById('feedback'),
        endModal=document.getElementById('endModal'),
        confirmEnd=document.getElementById('confirmEnd'),
        cancelEnd=document.getElementById('cancelEnd'),
        correct=parseInt('{{ correct_count|default:0 }}',10)||0;

  form.addEventListener('change',e=>{
    if(e.target&&e.target.name==='occurrence'){givenField.value=e.target.value||''}
  });

  let confirmed=false;
  form.addEventListener('submit',function(e){
    const chosen=form.querySelector('input[name="occurrence"]:checked');
    if(!confirmed){
      e.preventDefault();
      if(!chosen){showToast('من فضلك اختر إجابة أولًا.');return;}
      const val=parseInt(chosen.value,10);
      form.querySelectorAll('.q-option').forEach(el=>el.classList.remove('correct','wrong'));
      form.querySelectorAll('.q-option').forEach(el=>{
        const v=parseInt(el.querySelector('input').value,10);
        if(v===correct)el.classList.add('correct');
        if(el.querySelector('input').checked&&v!==correct)el.classList.add('wrong')
      });
      form.querySelectorAll('input[name="occurrence"]').forEach(inp=>{if(inp!==chosen)inp.disabled=true});
      feedbackBox.hidden=false;
      if(val===correct){feedbackBox.className='q-feedback ok';feedbackBox.textContent='إجابة صحيحة ✅'}
      else{feedbackBox.className='q-feedback err';feedbackBox.textContent='إجابة غير صحيحة ❌'}
      nextBtn.textContent='التالي'; confirmed=true; return;
    }
    nextBtn.disabled=true;
  });

  endBtn.addEventListener('click',()=>{endModal.classList.add('show');endModal.setAttribute('aria-hidden','false')});
  cancelEnd.addEventListener('click',()=>{endModal.classList.remove('show');endModal.setAttribute('aria-hidden','true')});
  confirmEnd.addEventListener('click',()=>endForm.submit());

  reportForm.addEventListener('submit',async function(e){
    e.preventDefault();
    try{
      const res=await fetch(reportForm.action,{method:'POST',headers:{'X-Requested-With':'XMLHttpRequest'},body:new FormData(reportForm)});
      const ct=res.headers.get('content-type')||''; let ok=false,msg='تم إرسال الإبلاغ. شكراً لك.';
      if(ct.includes('application/json')){const data=await res.json(); ok=!!data.ok; msg=data.message||msg}else ok=res.ok;
      if(ok){showToast(msg); reportForm.reset(); const d=reportForm.closest('details'); if(d)d.open=false}
      else showToast('تعذّر إرسال الإبلاغ. حاول مرة أخرى.');
    }catch(_){showToast('تعذّر الاتصال. تأكد من الشبكة وحاول مجددًا.')}
  });

  function showToast(t){
    if(!toast)return;
    toast.textContent=t; toast.classList.remove('show'); void toast.offsetWidth; toast.classList.add('show');
  }
})();
</script>
{% endblock %}

# ===== FILE: core/templates/core/test_result.html =====
{% extends "core/base.html" %}{% load static i18n arabic_extras highlight %}{% block title %}نتيجة الاختبار — متواتر{% endblock %}{% block content %}
<style>
:root{--r-text:#f3f4f6;--r-sub:#9aa3b2;--r-card:#11131d;--r-gold:#d4af37;--r-gold-2:#b88900;--r-ring:rgba(212,175,55,.35);--r-green:#22c55e;--r-red:#ef4444;--r-muted:#1d2230;--r-shadow:0 12px 36px rgba(0,0,0,.28);--r-radius:16px}
.r-wrap{max-width:980px;margin:20px auto;padding:14px;color:var(--r-text)}
.r-header{border:1px solid rgba(212,175,55,.22);background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border-radius:var(--r-radius);box-shadow:var(--r-shadow);padding:14px 16px;display:grid;gap:10px}
.r-scope{color:var(--r-sub);font-weight:800}
.r-top{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center}@media(max-width:720px){.r-top{grid-template-columns:1fr}}
.r-score{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.r-chip{display:inline-flex;align-items:center;gap:.45rem;background:#0f1118;color:var(--r-text);border:1px solid rgba(255,255,255,.1);border-radius:999px;padding:.42rem .7rem;font-weight:800}
.r-chip.ok{border-color:rgba(34,197,94,.45)}.r-chip.no{border-color:rgba(239,68,68,.45)}
.r-bar{min-width:220px;width:100%;height:14px;background:var(--r-muted);border-radius:999px;overflow:hidden;border:1px solid rgba(255,255,255,.08);display:flex}
.r-bar>span{display:block;height:100%;width:0%;transition:width .4s}.r-bar>.ok{background:linear-gradient(90deg,#16a34a,#22c55e)}.r-bar>.no{background:linear-gradient(90deg,#ef4444,#f87171)}
.r-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-start}
.btn{appearance:none;border:1px solid transparent;border-radius:12px;padding:10px 14px;font-weight:900;cursor:pointer}
.btn-primary{background:linear-gradient(180deg,var(--r-gold),var(--r-gold-2));color:#1a1200;border-color:rgba(212,175,55,.55)}
.btn-outline{background:#0f1118;color:var(--r-text);border-color:rgba(255,255,255,.12)}
.btn-ghost{background:#0f1118;color:var(--r-text);border-color:rgba(255,255,255,.08)}
.r-list{display:grid;gap:12px;margin-top:14px}
.r-item{background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border:1px solid rgba(255,255,255,.1);border-radius:var(--r-radius);box-shadow:var(--r-shadow);padding:12px 14px;display:grid;gap:8px}
.r-head{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
.r-phrase{margin:0;font-weight:900;color:#fff}
.status{font-weight:900;border-radius:10px;padding:.35rem .6rem;border:1px solid rgba(255,255,255,.1)}
.ok .status{background:linear-gradient(135deg,rgba(34,197,94,.14),rgba(34,197,94,.08));color:#eafff3;border-color:#22c55e}
.no .status{background:linear-gradient(135deg,rgba(239,68,68,.14),rgba(239,68,68,.08));color:#ffecec;border-color:#ef4444}
.meta{display:flex;gap:8px;flex-wrap:wrap;align-items:center;color:var(--r-sub);font-weight:800}
.m-chip{border:1px solid rgba(255,255,255,.1);border-radius:999px;padding:.25rem .55rem;background:#0f1118}
details{border-top:1px dashed rgba(255,255,255,.12);padding-top:8px}summary{cursor:pointer;color:var(--r-gold);font-weight:900}
.occ-list{list-style:none;padding:8px 0 0;margin:0;display:grid;gap:10px}
.ayah{background:#0f1118;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:10px 12px;display:grid;gap:4px}
.ayah-meta{color:var(--r-sub);font-size:.92rem;font-weight:800}.ayah-text{line-height:1.9}
.r-toolstrip{display:flex;gap:8px;align-items:center;margin-top:6px}.btn-sm{padding:.35rem .55rem;border-radius:10px}
.toast{position:fixed;inset-inline:16px;bottom:16px;z-index:50;display:none;padding:10px 12px;border-radius:12px;font-weight:800;background:#0f1118;color:#fff;border:1px solid rgba(212,175,55,.4);box-shadow:0 10px 30px rgba(0,0,0,.35)}
.toast.show{display:inline-block;animation:fadein .2s ease,fadeout .2s ease 2.6s forwards}
@keyframes fadein{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeout{to{opacity:0;transform:translateY(6px)}}
</style>

<div class="r-wrap" dir="rtl">
  <div id="toast" class="toast" aria-live="polite" aria-atomic="true"></div>
  <header class="r-header">
    <div class="r-scope">{{ scope_label }}</div>
    <div class="r-top">
      <div class="r-score">
        <span class="r-chip">النتيجة: <b>{{ score|arabic_digits }}</b> / <b>{{ total|arabic_digits }}</b></span>
        <span class="r-chip ok">صحيح: <b>{{ score|arabic_digits }}</b></span>
        <span class="r-chip no">خطأ: <b>{{ wrong|arabic_digits }}</b></span>
      </div>
      <div class="r-bar" id="rBar" data-score="{{ score }}" data-total="{{ total }}" data-wrong="{{ wrong }}"><span class="ok"></span><span class="no"></span></div>
    </div>
    <div class="r-actions">
      <a class="btn btn-primary" href="{% url 'core:test_selection' %}">ابدأ اختبارًا جديدًا</a>
      <a class="btn btn-outline" href="{% url 'core:main_menu' %}">الرجوع للرئيسية</a>
      <button type="button" class="btn btn-ghost" id="toggleAll">إظهار كل التفاصيل</button>
    </div>
  </header>

  <section class="r-list">
    {% for item in detailed_results %}
    {% with ga=item.given_answer|default_if_none:0 cc=item.correct_count|default_if_none:0 %}
    <article class="r-item {% if ga|add:0 == cc|add:0 %}ok{% else %}no{% endif %}">
      <div class="r-head"><h3 class="r-phrase">{{ item.phrase }}</h3><span class="status">{% if ga|add:0 == cc|add:0 %}إجابة صحيحة{% else %}إجابة خاطئة{% endif %}</span></div>
      <div class="meta">
        <span class="m-chip">إجابة الطالب: <b>{% if item.given_answer is not None %}{{ item.given_answer|arabic_digits }}{% else %}—{% endif %}</b></span>
        <span class="m-chip">الإجابة الصحيحة: <b>{{ cc|arabic_digits }}</b></span>
        <span class="m-chip">عدد المواضع: <b>{{ item.occurrences|length|arabic_digits }}</b></span>
      </div>
      <details {% if ga|add:0 != cc|add:0 %}open{% endif %}><summary>عرض مواضع العبارة</summary>
        <ol class="occ-list">
          {% for a in item.occurrences %}
          <li class="ayah">
            <div class="ayah-meta">سورة {{ a.surah|arabic_digits }}:{{ a.number|arabic_digits }}{% if a.juz_number %} — الجزء {{ a.juz_number|arabic_digits }}{% endif %}{% if a.quarter_label %} — {{ a.quarter_label }}{% endif %}</div>
            <div class="ayah-text">{{ a.text|highlight:item.phrase }}</div>
          </li>
          {% endfor %}
        </ol>
      </details>
    </article>
    {% endwith %}
    {% empty %}<div class="r-item">لا توجد تفاصيل لعرضها.</div>{% endfor %}
  </section>
</div>

<script>
(function(){
  const bar=document.getElementById('rBar');
  if(bar){
    const s=parseInt(bar.dataset.score||'0',10)||0,t=parseInt(bar.dataset.total||'1',10)||1,okPct=Math.max(0,Math.min(100,Math.round((s*100)/t))),noPct=100-okPct,ok=bar.querySelector('.ok'),no=bar.querySelector('.no');
    if(ok)ok.style.width=okPct+'%'; if(no)no.style.width=noPct+'%';
  }
  const btn=document.getElementById('toggleAll');
  if(btn){btn.addEventListener('click',()=>{const ds=document.querySelectorAll('.r-list details'),open=Array.from(ds).some(d=>!d.open); ds.forEach(d=>d.open=open); btn.textContent=open?'إخفاء كل التفاصيل':'إظهار كل التفاصيل'})}
})();
</script>
{% endblock %}

# ===== FILE: core/templates/core/test_selection.html =====
{% extends "core/base.html" %}{% load static i18n arabic_extras %}{% block title %}بدء اختبار — متواتر{% endblock %}{% block content %}
<style>
.page-shell{min-height:72vh;display:grid;gap:1rem}
.header-card{border:1px solid rgba(212,175,55,.22);background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border-radius:16px;padding:1rem 1.1rem;box-shadow:0 18px 44px rgba(0,0,0,.22)}
.header-card h1{margin:.25rem 0 .2rem;color:#fff;font-weight:900}.sub{color:var(--muted);margin:0}
.scope-tools{display:flex;align-items:center;justify-content:space-between;gap:.6rem;margin-top:.6rem}
.tiny-link{background:#0c1713;border:1px solid rgba(255,255,255,.1);color:var(--accent);font-weight:800;cursor:pointer;padding:.35rem .6rem;border-radius:10px}
.tiny-link:hover{filter:brightness(1.05)}
.stats{display:flex;gap:.6rem;flex-wrap:wrap;font-weight:800}
.stat-chip{display:inline-flex;gap:.45rem;align-items:center;background:#0c1713;border:1px solid rgba(255,255,255,.1);padding:.42rem .7rem;border-radius:999px;color:var(--text)}
.stat-chip .dot{width:8px;height:8px;border-radius:50%}.stat-chip .dot.juz{background:#16a34a}.stat-chip .dot.quarter{background:var(--accent)}
.accordion{display:grid;gap:.7rem}
.ac-item{background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border:1px solid rgba(255,255,255,.1);border-radius:14px;box-shadow:0 8px 26px rgba(0,0,0,.18)}
.ac-head{display:flex;align-items:center;gap:.6rem;padding:.65rem .75rem;justify-content:space-between}
.ac-left{display:flex;align-items:center;gap:.55rem}.ac-title{margin:0;color:#fff;font-weight:900;font-size:1rem}.tiny{font-size:.85rem;color:var(--muted)}
.expand{background:transparent;border:none;color:var(--accent);font-weight:800;cursor:pointer;padding:.25rem .4rem;border-radius:8px}
.expand:hover{text-decoration:underline}
.juz-all{position:relative;display:inline-grid;place-items:center;width:22px;height:22px;cursor:pointer}
.juz-all input{position:absolute;inset:0;opacity:0;cursor:pointer}
.juz-all .box{width:20px;height:20px;border-radius:6px;border:1px solid rgba(255,255,255,.18);background:#0c1713;box-shadow:inset 0 0 0 0 var(--accent);transition:box-shadow .18s,border-color .18s}
.juz-all input:checked+.box{border-color:var(--accent);box-shadow:inset 0 0 0 999px var(--accent)}
.ac-panel{padding:.1rem 0 .7rem;border-top:1px dashed rgba(255,255,255,.12)}.ac-panel[hidden]{display:none!important}
.q-list{display:grid;gap:.45rem;padding:.55rem .75rem .1rem}
@media (min-width:720px){.q-list{grid-template-columns:1fr 1fr}}
.q-item-row{position:relative;display:grid;grid-template-columns:auto 1fr;gap:.5rem;align-items:center;padding:.45rem .6rem;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:#0c1713;color:var(--text);cursor:pointer;user-select:none}
.q-item-row input{position:absolute;inset:0;opacity:0;cursor:pointer}
.q-item-row .tick{width:18px;height:18px;border-radius:5px;border:1px solid rgba(255,255,255,.2);background:transparent;position:relative}
.q-item-row input:checked+.tick{background:linear-gradient(135deg,var(--accent),var(--accent-2));border-color:var(--accent)}
.q-item-row input:checked+.tick::after{content:"";position:absolute;inset:3px 5px 3px 3px;border:2px solid #1b1b1b;border-top:0;border-left:0;transform:rotate(45deg)}
.q-name{font-weight:900}.q-meta{font-size:.85rem;color:var(--muted);margin-inline-start:.35rem}
.controls-card{border:1px solid rgba(255,255,255,.1);background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border-radius:16px;padding:.8rem 1rem;box-shadow:0 12px 32px rgba(0,0,0,.2)}
.controls{display:grid;grid-template-columns:1fr 1fr;gap:.8rem;align-items:center}@media (max-width:900px){.controls{grid-template-columns:1fr}}
.seg{display:flex;flex-wrap:wrap;gap:.4rem;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);padding:.35rem;border-radius:12px}
.seg input{display:none}.seg label{padding:.45rem .8rem;border-radius:10px;cursor:pointer;font-weight:900;border:1px solid rgba(255,255,255,.1);background:#0c1713;color:var(--text)}
.seg input:checked+label{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#1b1b1b;border-color:var(--accent)}
.actions{display:flex;gap:.6rem;flex-wrap:wrap;justify-content:center;margin-top:.2rem}
.btn-lg{padding:.8rem 1.15rem;border-radius:12px;font-weight:900}
</style>

<form method="post" action="{% url 'core:test_selection' %}">{% csrf_token %}
  <div class="page-shell">
    <section class="header-card">
      <h1>اختيار النطاق</h1>
      <p class="sub">اختر الأجزاء المطلوبة ثم افتح أي جزء لتحديد أرباعه (إن رغبت).</p>
      <div class="scope-tools">
        <button type="button" id="expandAll" class="tiny-link" data-state="closed">إظهار كل الأرباع</button>
        <div class="stats" id="stats"><span class="stat-chip"><span class="dot juz"></span> أجزاء مختارة: <b id="juzCount">0</b></span><span class="stat-chip"><span class="dot quarter"></span> أرباع مختارة: <b id="qCount">0</b></span></div>
      </div>
    </section>

    <section class="accordion" aria-label="اختيار الأجزاء والأرباع">
      {% for j, data in juz_quarters_map.items %}
      <article class="ac-item" data-juz="{{ j.number }}">
        <div class="ac-head">
          <div class="ac-left">
            <label class="juz-all" title="تحديد الجزء كاملًا"><input type="checkbox" class="juz-toggle" name="selected_juz" value="{{ j.number }}"><span class="box" aria-hidden="true"></span></label>
            <h3 class="ac-title">الجزء {{ j.number|arabic_digits }}</h3><span class="tiny">— {{ data.first_label }}</span>
          </div>
          <button type="button" class="expand" aria-expanded="false" aria-controls="q-{{ j.number }}">إظهار الأرباع</button>
        </div>
        <div class="ac-panel" id="q-{{ j.number }}" hidden>
          <div class="q-list">
            {% for q in data.quarters %}
            <label class="q-item-row"><input type="checkbox" class="q-item" name="selected_quarters" value="{{ q.id }}"><span class="tick" aria-hidden="true"></span><span class="q-name">الربع {{ q.index_in_juz }}</span><span class="q-meta">{{ q.label }}</span></label>
            {% endfor %}
          </div>
        </div>
      </article>
      {% endfor %}
    </section>

    <section class="controls-card" aria-label="إعدادات الاختبار">
      <div class="controls">
        <div><div class="tiny" style="margin:0 .2rem .35rem">عدد الأسئلة</div>
          <div class="seg">
            {% for n in num_questions_options %}
              <input type="radio" id="q{{ n }}" name="num_questions" value="{{ n }}" {% if forloop.first %}checked{% endif %}><label for="q{{ n }}">{{ n }}</label>
            {% endfor %}
          </div>
        </div>
        {% if selected_test_type != 'similar_on_pages' %}
        <div><div class="tiny" style="margin:0 .2rem .35rem">مستوى الصعوبة</div>
          <div class="seg">
            <input type="radio" id="d-mixed" name="difficulty" value="mixed" checked><label for="d-mixed">مختلط</label>
            <input type="radio" id="d-easy" name="difficulty" value="easy"><label for="d-easy">سهل</label>
            <input type="radio" id="d-medium" name="difficulty" value="medium"><label for="d-medium">متوسط</label>
            <input type="radio" id="d-hard" name="difficulty" value="hard"><label for="d-hard">صعب</label>
          </div>
        </div>
        {% endif %}
      </div>
    </section>

    <section class="actions">
      <a href="{% url 'core:main_menu' %}" class="btn btn-outline btn-lg">الرجوع للرئيسية</a>
      <button class="btn btn-primary btn-lg" type="submit">ابدأ الاختبار</button>
      <button class="btn btn-outline btn-lg" type="button" id="clearAll">تفريغ الاختيارات</button>
    </section>
  </div>
</form>

<script>
(function(){
  const items=document.querySelectorAll('.ac-item'),expandAll=document.getElementById('expandAll'),qCount=document.getElementById('qCount'),jCount=document.getElementById('juzCount'),clearBtn=document.getElementById('clearAll');
  function recalc(){const quarters=document.querySelectorAll('.q-item:checked'),juz=document.querySelectorAll('.juz-toggle:checked'); if(qCount)qCount.textContent=quarters.length; if(jCount)jCount.textContent=juz.length}
  function setOpen(card,open){const btn=card.querySelector('.expand'),panel=card.querySelector('.ac-panel'); if(!btn||!panel)return; panel.toggleAttribute('hidden',!open); btn.setAttribute('aria-expanded',open?'true':'false'); btn.textContent=open?'إخفاء الأرباع':'إظهار الأرباع'}
  items.forEach(card=>{
    const btn=card.querySelector('.expand'),panel=card.querySelector('.ac-panel'),toggle=card.querySelector('.juz-toggle'),quarters=card.querySelectorAll('.q-item');
    if(btn&&panel)btn.addEventListener('click',()=>{const isOpen=!panel.hasAttribute('hidden'); setOpen(card,!isOpen)});
    if(toggle)toggle.addEventListener('change',()=>{quarters.forEach(q=>q.checked=toggle.checked); recalc()});
    quarters.forEach(q=>q.addEventListener('change',()=>{if(toggle)toggle.checked=Array.from(quarters).every(x=>x.checked); recalc()}));
  });
  if(expandAll)expandAll.addEventListener('click',()=>{const open=expandAll.getAttribute('data-state')!=='open'; items.forEach(c=>setOpen(c,open)); expandAll.setAttribute('data-state',open?'open':'closed'); expandAll.textContent=open?'إخفاء كل الأرباع':'إظهار كل الأرباع'});
  if(clearBtn)clearBtn.addEventListener('click',()=>{document.querySelectorAll('.q-item,.juz-toggle').forEach(x=>x.checked=false); recalc(); window.scrollTo({top:0,behavior:'smooth'})});
  recalc();
})();
</script>
{% endblock %}

# ===== FILE: core/urls.py =====
# ===== FILE: core/urls.py =====
from django.urls import path
from . import views

app_name = "core"

urlpatterns = [
    # Landing على /
    path("", views.landing, name="landing"),

    # Main menu
    path("home/", views.main_menu, name="main_menu"),

    # Auth
    path("login/", views.login_view, name="login"),
    path("signup/", views.signup_view, name="signup"),
    path("logout/", views.logout_view, name="logout"),

    # Test flow
    path("test/", views.test_selection, name="test_selection"),
    path("start/", views.start_test, name="start_test"),
    path("test-question/", views.test_question, name="test_question"),
    path("report-question/", views.report_question, name="report_question"),

    # Complaints
    path("complaint/", views.complaint, name="complaint"),
    path("admin/complaints/", views.admin_complaints, name="admin_complaints"),

    path("account/", views.account_settings, name="account_settings"),

    path("stats/", views.stats, name="stats"),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
    path("tests/", views.test_catalog, name="test_catalog"),
    path("api/quarter/<int:qid>/pages/", views.quarter_pages_api, name="quarter_pages_api"),
    path("api/page/<int:pno>/ayat/", views.page_ayat_api, name="page_ayat_api"),
    path("quarter/<int:qid>/pages/", views.quarter_pages_view, name="quarter_pages_view"),
    path("page-svg/<int:pno>.svg", views.page_svg, name="page_svg_proxy"),
    path("test/pages/choose-juz/", views.pages_choose_juz, name="pages_choose_juz"),
    path("test/pages/choose-quarter/<int:juz_no>/", views.pages_choose_quarter, name="pages_choose_quarter"),
    path("test/pages/quarter/<int:qid>/", views.pages_quarter_pick, name="pages_quarter_pick"),
    path("api/test/pages/select-first/", views.api_pages_select_first, name="api_pages_select_first"),
    path("test/pages/quarter/<int:qid>/viewer/", views.pages_quarter_viewer, name="pages_quarter_viewer"),
    path("test/page-svg/<int:pno>/", views.page_svg, name="page_svg"),









]

# ===== FILE: core/views.py =====
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.db.models import Count, Sum, Q, Exists, OuterRef
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.urls import reverse
from django.http import JsonResponse, FileResponse, Http404
from django.conf import settings
import os, math, random, re, unicodedata
from django.views.decorators.http import require_POST
from .forms import AccountForm, PasswordChangeTightForm
from .models import Student, Complaint, Juz, Quarter, SimilarityGroup, Ayah, Phrase, PhraseOccurrence, TestSession, TestQuestion, Page
from django.contrib.auth import get_user_model
from django.test import TestCase



AR_ORD={1:"الأول",2:"الثاني",3:"الثالث",4:"الرابع",5:"الخامس",6:"السادس",7:"السابع",8:"الثامن",9:"التاسع",10:"العاشر"}
def ar_ordinal(n:int)->str: return f"{AR_ORD.get(n,n)}"

PAGES_BONUS_ORDER=15; PENALTY_WRONG_JUZ_OTHER=8; PENALTY_WRONG_QUARTER_OTHER=6; PENALTY_EMPTY_JUZ=5; PENALTY_EMPTY_QUARTER=4; FAIL_THRESHOLD=50

def _grade_state(request):
    st=request.session.get('pages_grade') or {}
    st.setdefault('bonus',0); st.setdefault('penalty',0); st.setdefault('events',[]); st.setdefault('order_set',False)
    request.session['pages_grade']=st; return st

def _grade_push(request,text:str,delta:int):
    st=_grade_state(request)
    if delta>=0: st['bonus']=min(100,int(st.get('bonus',0))+int(delta))
    else: st['penalty']=min(100,int(st.get('penalty',0))+int(-delta))
    st['events'].insert(0,{'t':text,'d':int(delta)}); request.session['pages_grade']=st
    score=max(0,min(100,100-int(st['penalty'])+int(st['bonus']))); return int(score),int(delta)

def _grade_get(request):
    st=_grade_state(request); score=max(0,min(100,100-int(st.get('penalty',0))+int(st.get('bonus',0)))); return int(score),st

def _grade_mark_order(request):
    st=_grade_state(request)
    if not st.get('order_set'):
        st['order_set']=True; request.session['pages_order']=True; _grade_push(request,"اختيار بالترتيب (Bonus)",+PAGES_BONUS_ORDER)
    return _grade_get(request)

def _current_question_and_flow(request):
    qs=request.session.get('questions') or []; flow=request.session.get('pages_flow') or {}; q_index=flow.get('q_index')
    if q_index is None or not (0<=q_index<len(qs)): return None,flow
    return qs[q_index],flow

def _feedback(kind:str,text:str): return {"kind":kind,"level":kind,"text":text,"message":text}

def _allowed_juz_numbers_for_scope(request):
    sel_quarters=request.session.get('selected_quarters') or []; sel_juz=request.session.get('selected_juz') or []
    quarters_with_pages=Quarter.objects.filter(id=OuterRef('id'),ayah__page__isnull=False)
    qs=Quarter.objects.all().annotate(has_pages=Exists(quarters_with_pages)).filter(has_pages=True)
    if sel_quarters: qs=qs.filter(id__in=sel_quarters)
    elif sel_juz:
        try: sel_juz=[int(j) for j in sel_juz]
        except Exception: sel_juz=[]
        if sel_juz: qs=qs.filter(juz__number__in=sel_juz)
    allowed=sorted(set(qs.values_list('juz__number',flat=True)))
    if not allowed:
        qs_any=Quarter.objects.annotate(has_pages=Exists(Quarter.objects.filter(id=OuterRef('id'),ayah__page__isnull=False))).filter(has_pages=True)
        allowed=sorted(set(qs_any.values_list('juz__number',flat=True)))
    return allowed

def _ctx_common(request, extra=None, feedback=None, delta=None):
    extra = extra or {}
    q, _ = _current_question_and_flow(request)
    score_now, st = _grade_get(request)

    gauge_score = max(0, min(100, int(score_now)))
    extra['score_now'] = gauge_score
    extra['gauge_score'] = gauge_score
    extra['gauge_events'] = list(st.get('events') or [])[:6]

    flow = _current_flow(request)
    step_no = int(flow.get('current') or 1)
    total = int(flow.get('total') or 0)
    progress_pct = 0 if total == 0 else int(round((step_no - 1) * 100 / total))
    extra['step_no'] = step_no
    extra['target_total'] = total
    extra['progress_pct'] = progress_pct

    phrase = ''
    if q: phrase = q.get('phrase_text') or q.get('phrase') or ''
    extra['current_phrase'] = phrase or '—'
    extra['step_label'] = f"الموضع {ar_ordinal(step_no)}" + (f" من {total}" if total else "")

    # ← العلم اللي يتحكم بظهور الدائرة في الـlayout
    extra['show_pages_progress'] = (request.session.get('selected_test_type') == 'similar_on_pages')

    if feedback: extra['feedback'] = feedback
    if delta is not None: extra['delta'] = int(delta)
    return extra




DIAC=re.compile(r'[\u064B-\u0652\u0670\u06DF-\u06ED]')
def norm(txt:str)->str:
    txt=unicodedata.normalize('NFKD',txt); txt=DIAC.sub('',txt)
    txt=txt.replace('إ','ا').replace('أ','ا').replace('آ','ا'); txt=txt.replace('ة','ه').replace('ى','ي')
    txt=re.sub(r'[^\w\s]','',txt); return txt

WORD_ALIASES={'تكن':r'تكون(?:ن|نَّ)?','قول':r'قول(?:وا)?','تلبسون':r'تلبسون?|تلبسوا(?:ن)?'}
def flex_regex(word_list):
    parts=[];
    for w in word_list:
        key=norm(w); parts.append(WORD_ALIASES.get(key,re.escape(key)))
    return r'\s+'.join(parts)

ALLOWED_NUM_QUESTIONS=[5,10,15,20]
COMPLAINT_TYPES=["خطأ في السؤال","تصميم / واجهة","اقتراح تحسين","إضافة ميزة","مشكلة تقنية","أخرى"]

def make_options(correct_count:int):
    pool={correct_count}
    for off in(-3,-2,-1,1,2,3,4,5):
        v=correct_count+off
        if v>=1: pool.add(v)
        if len(pool)>=4: break
    return sorted(pool)[:4]

def _build_scope_label(selected_juz_ids,selected_quarter_ids):
    if selected_quarter_ids:
        quarters=Quarter.objects.filter(id__in=selected_quarter_ids).select_related('juz'); by_juz={}
        for q in quarters: by_juz.setdefault(q.juz.number,[]).append(q)
        parts=[]
        for j in sorted(by_juz):
            qs=by_juz[j]
            if len(qs)==8: parts.append(f"الجزء {j}")
            else:
                idx=', '.join(f"الربع {q.index_in_juz}" for q in sorted(qs,key=lambda x:x.index_in_juz))
                parts.append(f"الجزء {j} - {idx}")
        return "اختبار على: " + "؛ ".join(parts)
    elif selected_juz_ids:
        lbl='؛ '.join(f"الجزء {j}" for j in sorted(selected_juz_ids)); return f"اختبار على: {lbl}"
    return "اختبار على: نطاق غير محدد"

def landing(request):
    if request.user.is_authenticated:
        student,_=Student.objects.get_or_create(user=request.user,defaults={'display_name':request.user.username})
        request.session['student_id']=student.id; return redirect('core:main_menu')
    return render(request,'core/landing.html',{'hide_footer':False,'show_splash':True,'is_logged_in':False})

def login_view(request):
    if request.user.is_authenticated:
        student,_=Student.objects.get_or_create(user=request.user,defaults={'display_name':request.user.username})
        request.session['student_id']=student.id; return redirect('core:main_menu')
    if request.method=='POST':
        identifier=request.POST.get('username','').strip(); password=request.POST.get('password','').strip()
        if not identifier or not password: messages.error(request,"كل الحقول مطلوبة لتسجيل الدخول."); return redirect('core:login')
        user_obj=None; stu=Student.objects.select_related('user').filter(display_name__iexact=identifier).first()
        if stu: user_obj=stu.user
        else:
            user_obj=User.objects.filter(username__iexact=identifier).first()
            if not user_obj: user_obj=User.objects.filter(email__iexact=identifier).first()
        user=authenticate(request,username=user_obj.username,password=password) if user_obj else None
        if user is None: messages.error(request,"اسم الدخول/البريد أو كلمة المرور غير صحيحة."); return redirect('core:login')
        login(request,user); student,_=Student.objects.get_or_create(user=user,defaults={'display_name':user.username})
        request.session['student_id']=student.id; return redirect('core:main_menu')
    return render(request,'core/login.html',{'hide_footer':False})

def signup_view(request):
    if request.user.is_authenticated: return redirect('core:main_menu')
    if request.method=='POST':
        student_name=request.POST.get('student_name','').strip(); password=request.POST.get('password','').strip()
        if not student_name: messages.error(request,"اسم الطالب مطلوب للتسجيل."); return redirect('core:signup')
        if not password: messages.error(request,"كلمة المرور مطلوبة."); return redirect('core:signup')
        username=student_name.lower().replace(' ','_')
        try: tmp_user=User(username=username,email=""); validate_password(password,user=tmp_user)
        except ValidationError as e: messages.error(request," ".join(e.messages)); return redirect('core:signup')
        if Student.objects.filter(display_name__iexact=student_name).exists(): messages.error(request,"اسم الطالب مستخدم بالفعل. لو ده حسابك جرّب تسجيل الدخول، أو اختر اسمًا مميزًا."); return redirect('core:signup')
        if User.objects.filter(username=username).exists(): messages.error(request,"اسم المستخدم موجود بالفعل. جرّب تعديل الاسم قليلًا."); return redirect('core:signup')
        try: user=User.objects.create_user(username=username); user.set_password(password); user.save()
        except IntegrityError: messages.error(request,"حصل خطأ في إنشاء الحساب، جرب اسم آخر."); return redirect('core:signup')
        student=Student.objects.create(user=user,display_name=student_name); login(request,user); request.session['student_id']=student.id; return redirect('core:main_menu')
    return render(request,'core/signup.html',{'hide_footer':False})

@login_required
def logout_view(request): logout(request); messages.success(request,"تم تسجيل الخروج."); return redirect('core:login')

@login_required
def main_menu(request):
    sid=request.session.get('student_id')
    if not sid:
        student,_=Student.objects.get_or_create(user=request.user,defaults={'display_name':request.user.username})
        request.session['student_id']=student.id
    student=get_object_or_404(Student,id=request.session['student_id']); stats=_user_stats(student); lb_all=_leaderboard()
    my_rank=next((r['rank'] for r in lb_all if r['student_id']==student.id),None)
    return render(request,'core/main_menu.html',{'student':student,'stats':stats,'my_rank':my_rank,'show_splash':True,'hide_footer':False})

def _score_formula(exams,correct,wrong,unanswered):
    base=correct-0.6*wrong-0.2*unanswered; acc=(correct/(correct+wrong)) if (correct+wrong) else 0.0; volume_bonus=min(exams,30)*2
    return round(max(0,base+40*acc+volume_bonus),2)

@login_required
def leaderboard(request):
    student=get_object_or_404(Student,user=request.user); rows=_leaderboard()
    my_rank=next((r['rank'] for r in rows if r['student_id']==student.id),None)
    return render(request,'core/leaderboard.html',{'rows':rows,'student':student,'my_rank':my_rank,'hide_footer':False})

def _leaderboard():
    sess=TestSession.objects.filter(completed=True).values('student').annotate(exams=Count('id'),total_q=Sum('num_questions'))
    ans=TestQuestion.objects.filter(session__completed=True).values('session__student').annotate(answered=Count('id'),correct=Count('id',filter=Q(is_correct=True)),wrong=Count('id',filter=Q(is_correct=False)))
    by_student={}
    for r in sess:
        sid=r['student']; by_student[sid]={'student_id':sid,'exams':r.get('exams',0) or 0,'total_q':r.get('total_q',0) or 0,'answered':0,'correct':0,'wrong':0}
    for r in ans:
        sid=r['session__student']; row=by_student.setdefault(sid,{'student_id':sid,'exams':0,'total_q':0,'answered':0,'correct':0,'wrong':0})
        row['answered']=(row['answered'] or 0)+(r.get('answered',0) or 0); row['correct']=(row['correct'] or 0)+(r.get('correct',0) or 0); row['wrong']=(row['wrong'] or 0)+(r.get('wrong',0) or 0)
    if not by_student: return []
    sids=list(by_student.keys()); students=Student.objects.select_related('user').filter(id__in=sids); stu_map={s.id:s for s in students}
    rows=[]
    for sid,r in by_student.items():
        s=stu_map.get(sid);
        if not s: continue
        exams=r['exams'] or 0
        if exams<=0: continue
        correct=r['correct'] or 0; wrong=r['wrong'] or 0; answered=r['answered'] or 0; total_q=r['total_q'] or 0; unanswered=max(0,total_q-answered)
        denom=max(1,correct+wrong+unanswered); accuracy=correct/denom
        score=(600.0*accuracy)+(300.0*math.log10(1+correct))+(100.0*math.log10(1+exams))-(10.0*unanswered); score=int(round(max(0,score)))
        rows.append({'student_id':sid,'display_name':s.display_name or s.user.username,'avatar':s.avatar.url if getattr(s,'avatar',None) else '','exams':exams,'correct':correct,'wrong':wrong,'unanswered':unanswered,'accuracy':accuracy,'accuracy_pct':round(accuracy*100,2),'score':score})
    rows.sort(key=lambda x:(-x['score'],-x['accuracy'],-x['correct'],x['display_name']))
    last_score=None; rank=0
    for i,r in enumerate(rows,start=1):
        if r['score']!=last_score: rank=i; last_score=r['score']
        r['rank']=rank
    return rows

@login_required
def complaint(request):
    sid=request.session.get('student_id')
    if not sid: messages.warning(request,"الرجاء تسجيل الدخول أولاً."); return redirect('core:login')
    student=get_object_or_404(Student,id=sid)
    if request.method=='POST':
        cats=request.POST.getlist('category'); txt=request.POST.get('text','').strip()
        if not txt and not cats: messages.error(request,"لا يمكن إرسال شكوى فارغة.")
        else:
            prefix=f"[{', '.join(cats)}] " if cats else ''
            Complaint.objects.create(student=student,text=prefix+txt if txt else prefix); messages.success(request,"تم إرسال الشكوى/الاقتراح بنجاح."); return redirect('core:main_menu')
    return render(request,'core/complaint.html',{'student':student,'types':COMPLAINT_TYPES,'hide_footer':False})

def test_catalog(request):
    tests=[{"key":"similar_count","title":" عدد مواضع المتشابهات","desc":"يعرض عبارة ويطلب عدد مواضعها الصحيحة في نطاقك.","available":True,"url":reverse("core:test_selection")+"?type=similar_count"},{"key":"similar_on_pages","title":"مواضع المتشابهات في الصفحات","desc":"اختيار النطاق ثم تحديد الصفحات والمواضع لكل سؤال.","available":True,"url":reverse("core:test_selection")+"?type=similar_on_pages"},{"key":"page_edges_quarters","title":"بداية ونهاية الصفحات مع الأرباع","desc":"استنتاج بدايات/نهايات الآيات بين الصفحات داخل نطاقك.","available":False},{"key":"order_juz_quarters","title":"اختبار ترتيب الأجزاء والأرباع","desc":"أسئلة لقياس ترتيب الأجزاء والأرباع وتسلسلها.","available":False},{"key":"semantic_similarities","title":"متشابهات معاني الآيات","desc":"أسئلة على التشابه الدلالي للمعاني.","available":False}]
    return render(request,"core/test_catalog.html",{"tests":tests,"hide_footer":False})

@login_required
def test_selection(request):
    sid=request.session.get('student_id')
    if not sid: messages.warning(request,"الرجاء إدخال اسمك أولاً."); return redirect('core:login')
    student=get_object_or_404(Student,id=sid)
    test_type_qs=request.GET.get('type')
    if test_type_qs: request.session['selected_test_type']=test_type_qs
    if not request.session.get('selected_test_type'): request.session['selected_test_type']='similar_count'
    if request.method=='POST':
        sel_juz=request.POST.getlist('selected_juz'); sel_q=request.POST.getlist('selected_quarters')
        try: num_q=int(request.POST.get('num_questions',5))
        except ValueError: num_q=5
        if num_q not in [5,10,15,20]: num_q=5
        difficulty=request.POST.get('difficulty','mixed')
        sel_juz=[int(j) for j in sel_juz if str(j).isdigit()]; sel_q=[int(q) for q in sel_q if str(q).isdigit()]
        if not sel_juz and not sel_q: messages.error(request,"لازم تختار جزء أو رُبع."); return redirect('core:test_selection')
        request.session.update({'selected_juz':sel_juz,'selected_quarters':sel_q,'num_questions':num_q,'difficulty':difficulty,'test_index':0,'score':0})
        request.session.pop('scope_label',None); return redirect('core:start_test')
    juz_list=Juz.objects.all().order_by('number'); juz_quarters_map={}
    for j in juz_list:
        qs=list(Quarter.objects.filter(juz=j).order_by('index_in_juz')); first_label=qs[0].label if qs else ''
        juz_quarters_map[j]={'quarters':qs,'first_label':first_label}
    return render(request,'core/test_selection.html',{'student':student,'juz_quarters_map':juz_quarters_map,'num_questions_options':[5,10,15,20],'show_splash':True,'hide_footer':False,'selected_test_type':request.session.get('selected_test_type','similar_count')})

@login_required
def start_test(request):
    sid=request.session.get('student_id')
    if not sid: messages.warning(request,"الرجاء إدخال اسمك أولاً."); return redirect('core:login')
    student=get_object_or_404(Student,id=sid)
    juz_ids=request.session.get('selected_juz',[]); q_ids=request.session.get('selected_quarters',[])
    desired=int(request.session.get('num_questions',5)); difficulty=request.session.get('difficulty','mixed')
    if q_ids: ayat_qs=Ayah.objects.filter(quarter_id__in=q_ids)
    elif juz_ids: ayat_qs=Ayah.objects.filter(quarter__juz__number__in=juz_ids)
    else: messages.error(request,"مفيش نطاق محدد."); return redirect('core:test_selection')
    if not ayat_qs.exists(): messages.error(request,"النطاق لا يحتوى آيات."); return redirect('core:test_selection')

    ayat_ids=list(ayat_qs.values_list('id',flat=True)); MAX_OCC_SCOPE=60
    stats=(PhraseOccurrence.objects.filter(ayah_id__in=ayat_ids).values('phrase_id')
           .annotate(freq=Count('id')).filter(freq__gte=2,freq__lte=MAX_OCC_SCOPE))
    if not stats: messages.error(request,"مافيش عبارات متشابهة كافية فى النطاق."); return redirect('core:test_selection')

    phrase_ids=[s['phrase_id'] for s in stats]; freq_map={s['phrase_id']:s['freq'] for s in stats}
    occ_rows=PhraseOccurrence.objects.filter(ayah_id__in=ayat_ids,phrase_id__in=phrase_ids).values('phrase_id','ayah_id')
    occ_by_phrase={};
    for r in occ_rows: occ_by_phrase.setdefault(r['phrase_id'],set()).add(r['ayah_id'])
    phrases={p.id:p for p in Phrase.objects.filter(id__in=phrase_ids)}
    sorted_pids=sorted(phrase_ids,key=lambda pid:(-phrases[pid].length_words,-freq_map[pid],phrases[pid].text))
    kept,kept_sets=[],[];
    for pid in sorted_pids:
        aset=occ_by_phrase[pid]
        if any(aset.issubset(S) for S in kept_sets): continue
        kept.append(pid); kept_sets.append(aset)

    def bucket(ph_len,freq):
        if ph_len>=5 and 2<=freq<=3: return 'easy'
        if ph_len>=4 and 2<=freq<=6: return 'medium'
        if ph_len>=3 and 7<=freq<=60: return 'hard'
        return 'other'

    candidates=[]
    for pid in kept:
        ph=phrases[pid]; freq=freq_map[pid]; b=bucket(ph.length_words,freq)
        if b=='other': continue
        ayahs=(Ayah.objects.filter(id__in=occ_by_phrase[pid]).select_related('quarter__juz').order_by('surah','number'))
        literal=[{'surah':a.surah,'number':a.number,'juz_number':a.quarter.juz.number if a.quarter else None,'quarter_label':a.quarter.label if a.quarter else None,'text':a.text} for a in ayahs]
        candidates.append({'phrase_id':pid,'phrase_text':ph.text,'correct_count':freq,'occurrence_ayah_ids':list(occ_by_phrase[pid]),'literal_ayahs':literal,'bucket':b,'score':freq*math.log(1+ph.length_words)})

    if not candidates: messages.error(request,"بعد تطبيق مستوى الصعوبة مابقاش فيه أسئلة مناسبة."); return redirect('core:test_selection')

    if difficulty=='mixed':
        E=[c for c in candidates if c['bucket']=='easy']; M=[c for c in candidates if c['bucket']=='medium']; H=[c for c in candidates if c['bucket']=='hard']
        random.shuffle(E); random.shuffle(M); random.shuffle(H)
        ne=max(0,round(desired*0.40)); nm=max(0,round(desired*0.45)); nh=max(0,desired-ne-nm)
        take=E[:ne]+M[:nm]+H[:nh]
        for pool in [M[nm:],E[ne:],H[nh:]]:
            if len(take)>=desired: break
            need=desired-len(take); take+=pool[:need]
        selected=take[:desired]; random.shuffle(selected)
    else:
        filtered=[c for c in candidates if c['bucket']==difficulty]
        if not filtered: messages.error(request,"لا توجد أسئلة مناسبة لهذا المستوى في النطاق."); return redirect('core:test_selection')
        filtered.sort(key=lambda x:(-x['score'],x['phrase_text'])); selected=filtered[:desired]

    selected_type=request.session.get('selected_test_type','similar_count')
    session_db=TestSession.objects.create(student=student,test_type=selected_type,num_questions=len(selected),difficulty=difficulty,completed=False)
    if juz_ids: session_db.juzs.add(*Juz.objects.filter(number__in=juz_ids))
    if q_ids: session_db.quarters.add(*Quarter.objects.filter(id__in=q_ids))

    request.session['db_session_id']=session_db.id
    db_qids=[TestQuestion.objects.create(session=session_db).id for _ in selected]
    request.session['db_question_ids']=db_qids
    request.session['scope_label']=_build_scope_label(juz_ids,q_ids)
    request.session['questions']=[{'phrase_id':c['phrase_id'],'phrase_text':c['phrase_text'],'correct_count':c['correct_count'],'occurrence_ayah_ids':c['occurrence_ayah_ids'],'literal_ayahs':c['literal_ayahs'],'given_answer':None} for c in selected]
    request.session['test_index']=0; request.session['score']=0

    # تهيئة تدفّق هذا الاختبار (namespaced)
    total=len(selected); ns=_ns(request,f'flow:{session_db.id}')
    request.session[ns]={'current':1,'total':int(total)}; request.session.modified=True

    # اختياري: تهيئة قديمة للحفاظ على التوافق لو عندك كود لسه بيقرأ pages_flow
    request.session[_ns(request,'pages_flow')]={'current':1,'total':int(total)}; request.session.modified=True

    return redirect('core:test_question')

# helper صغير يجيب تدفّق الاختبار الحالي (current/total) من الـsession
def _current_flow(request):
    tid=request.session.get('db_session_id')
    return request.session.get(_ns(request,f'flow:{tid}')) or {}


@login_required
def test_question(request):
    sid=request.session.get('student_id')
    if not sid: messages.warning(request,"الرجاء إدخال اسمك أولاً."); return redirect('core:login')
    student=get_object_or_404(Student,id=sid); idx=request.session.get('test_index',0); qs=request.session.get('questions',[]); total=len(qs)
    if idx>=total:
        score=request.session.get('score',0); scope_lbl=request.session.get('scope_label','')
        detailed=[{'phrase':q.get('phrase_text') or q.get('phrase',''),'correct_count':q.get('correct_count'),'given_answer':q.get('given_answer'),'occurrences':q.get('literal_ayahs',[])} for q in qs]
        wrong=max(0,total-score); db_sid=request.session.get('db_session_id')
        if db_sid: TestSession.objects.filter(id=db_sid).update(completed=True)
        for k in ['questions','test_index','score','selected_juz','selected_quarters','num_questions','scope_label','difficulty','db_session_id','db_question_ids']: request.session.pop(k,None)
        return render(request,'core/test_result.html',{'student':student,'score':score,'total':total,'detailed_results':detailed,'scope_label':scope_lbl,'wrong':wrong,'hide_footer':True})
    question=qs[idx]; progress=round((idx+1)/total*100) if total else 0
    if request.method=='POST' and request.POST.get('action')=='end':
        db_sid=request.session.get('db_session_id')
        if db_sid: TestSession.objects.filter(id=db_sid).update(completed=True)
        request.session['test_index']=len(qs); return redirect('core:test_question')
    if request.method=='POST':
        ans=request.POST.get('occurrence')
        try: qs[idx]['given_answer']=int(ans)
        except (ValueError,TypeError): qs[idx]['given_answer']=None
        request.session['questions']=qs
        try: correct_count=int(question.get('correct_count'))
        except (TypeError,ValueError): correct_count=-1
        db_qids=request.session.get('db_question_ids') or []
        if isinstance(db_qids,list) and idx<len(db_qids):
            given=qs[idx]['given_answer']; is_corr=bool(given is not None and int(given)==correct_count)
            TestQuestion.objects.filter(id=db_qids[idx]).update(student_response=str(given if given is not None else ''),is_correct=is_corr)
        selected_type=request.session.get('selected_test_type','similar_count')
        try: ans_val=int(ans) if ans and ans.isdigit() else None
        except Exception: ans_val=None
        if selected_type=='similar_on_pages':
            correct_count_val=correct_count; request.session['pages_flow']={'q_index':idx,'target_total':correct_count_val,'current':1}
            _flow_set_total(request,correct_count_val); return redirect('core:pages_choose_juz')
        if ans and ans.isdigit() and int(ans)==correct_count: request.session['score']=request.session.get('score',0)+1
        request.session['test_index']=idx+1; return redirect('core:test_question')
    phrase_txt=question.get('phrase_text') or question.get('phrase')
    if not phrase_txt:
        pid=question.get('phrase_id')
        if pid:
            try: phrase_txt=Phrase.objects.only('text').get(id=pid).text
            except Phrase.DoesNotExist: phrase_txt=''
        else: phrase_txt=''
    try: correct_count=int(question.get('correct_count'))
    except (TypeError,ValueError): correct_count=2
    options=make_options(correct_count)
    return render(request,'core/test_question.html',{'student':student,'question_number':idx+1,'total_questions':total,'phrase':phrase_txt,'options':options,'scope_label':request.session.get('scope_label',''),'progress_percent':progress,'correct_count':correct_count,'submitted':False,'hide_footer':True})

@user_passes_test(lambda u:u.is_staff)
def admin_complaints(request):
    comps=Complaint.objects.select_related('student__user').order_by('-created_at')
    if request.method=='POST':
        cid=request.POST.get('complaint_id'); action=request.POST.get('action')
        try:
            c=Complaint.objects.get(id=cid)
            if action=='toggle': c.resolved=not c.resolved; c.save(); messages.success(request,f"تم تحديث حالة الشكوى #{cid}.")
        except Complaint.DoesNotExist: messages.error(request,"الشكوى غير موجودة.")
    return render(request,'core/complaint_admin.html',{'complaints':comps,'hide_footer':False})

@login_required
@require_POST
def report_question(request):
    sid=request.session.get('student_id'); student=get_object_or_404(Student,id=sid)
    text=(request.POST.get('text','') or '').strip() or '(بدون وصف)'; phrase=(request.POST.get('phrase','') or '').strip(); q_no=request.POST.get('question_number','?'); given=request.POST.get('given','—'); correct=request.POST.get('correct','—'); src=request.POST.get('from','test')
    body=f"[إبلاغ سؤال — المصدر: {src}] سؤال رقم: {q_no} | العبارة: \"{phrase}\" | إجابة الطالب: {given} | الصحيحة: {correct}\nوصف المشكلة: {text}"
    Complaint.objects.create(student=student,text=body)
    if request.headers.get('x-requested-with')=='XMLHttpRequest': return JsonResponse({"ok":True,"message":"تم إرسال الإبلاغ. شكراً لك."})
    return render(request,'core/report_done.html',{'hide_footer':True})

@login_required
def account_settings(request):
    user=request.user; student=Student.objects.filter(user=user).first()
    if request.method=="POST":
        action=request.POST.get("action")
        if action=="update_profile":
            form=AccountForm(request.POST,request.FILES)
            if form.is_valid():
                display_name=form.cleaned_data["display_name"]; email=form.cleaned_data.get("email") or ""; avatar=request.FILES.get("avatar"); remove_avatar=request.POST.get("remove_avatar")=="1"
                if student: student.display_name=display_name; student.save(update_fields=["display_name"])
                user.email=email; user.save(update_fields=["email"])
                if remove_avatar and student and student.avatar: student.avatar.delete(save=True); messages.success(request,_("تم حذف الصورة."))
                if avatar:
                    try:
                        _validate_avatar(avatar)
                        if not student: student=Student.objects.create(user=user,display_name=user.username)
                        student.avatar.save(avatar.name,avatar,save=True); messages.success(request,_("تم تحديث الصورة."))
                    except ValidationError as e: messages.error(request,"; ".join(e.messages))
                messages.success(request,_("تم حفظ التغييرات.")); return redirect("core:account_settings")
            else: messages.error(request,_("تحقق من المدخلات."))
        elif action=="change_password":
            pform=PasswordChangeTightForm(user,request.POST)
            if pform.is_valid(): pform.save(); messages.success(request,_("تم تحديث كلمة المرور.")); return redirect("core:account_settings")
            else: messages.error(request,_("لم يتم تغيير كلمة المرور."))
    profile_form=AccountForm(initial={"display_name":getattr(student,"display_name",user.username),"email":user.email}); password_form=PasswordChangeTightForm(user)
    return render(request,"core/account_settings.html",{"profile_form":profile_form,"password_form":password_form})

def _user_stats(student:Student):
    qs=TestQuestion.objects.filter(session__student=student); total_qs=qs.count(); correct=qs.filter(is_correct=True).count()
    wrong=qs.filter(is_correct=False).exclude(student_response='').exclude(student_response__isnull=True).count()
    answered=qs.exclude(student_response='').exclude(student_response__isnull=True).count(); unanswered=max(0,total_qs-answered)
    exams=TestSession.objects.filter(student=student,completed=True).count()
    return {'exams':exams,'correct':correct,'wrong':wrong,'unanswered':unanswered}

@login_required
def stats(request):
    student=get_object_or_404(Student,user=request.user); data=_user_stats(student)
    return render(request,'core/stats.html',{'student':student,'stats':data,'hide_footer':False})

@login_required
def quarter_pages_api(request,qid:int):
    qs=Ayah.objects.filter(quarter_id=qid,page__isnull=False).values_list('page__number',flat=True).distinct()
    pages=sorted(set(p for p in qs if p is not None)); pmin=pages[0] if pages else None
    return JsonResponse({"pages":[{"page_number":p,"index_in_quarter":(p-pmin+1) if pmin else None} for p in pages]})

@login_required
def page_ayat_api(request,pno:int):
    ay=Ayah.objects.filter(page__number=pno).order_by('surah','number').values('id','surah','number','text','quarter_id')
    return JsonResponse({"page":pno,"ayat":[{"id":a["id"],"vk":f"{a['surah']}:{a['number']}","text":a["text"],"quarter_id":a["quarter_id"]} for a in ay]})

@login_required
def quarter_pages_view(request,qid:int):
    pg_nums=Ayah.objects.filter(quarter_id=qid,page__isnull=False).values_list('page__number',flat=True); pg_nums=sorted(set(pg for pg in pg_nums if pg is not None))
    pages=Page.objects.filter(number__in=pg_nums).order_by('number')
    return render(request,'core/quarter_pages.html',{'qid':qid,'pages':pages,'hide_footer':True})

def page_svg(request,pno:int):
    candidates=[f"{pno}.svg",f"{pno:02d}.svg",f"{pno:03d}.svg"]; base=os.path.join(settings.MEDIA_ROOT,'pages')
    for fname in candidates:
        path=os.path.join(base,fname)
        if os.path.exists(path) and os.path.getsize(path)>0: return FileResponse(open(path,'rb'),content_type='image/svg+xml')
    raise Http404("Page SVG not found")

@login_required
def pages_quarter_pick(request,qid:int):
    sid=request.session.get('student_id'); student=get_object_or_404(Student,id=sid)
    qobj=get_object_or_404(Quarter,id=qid); juz_no_for_q=qobj.juz.number
    question,flow=_current_question_and_flow(request); feedback=None; delta=None
    if question:
        expected=int((request.session.get(_ns(request,'pages_flow')) or {}).get('current',1))
        occ_ids=question.get('occurrence_ayah_ids',[]) or []
        ay_quarters=list(Ayah.objects.filter(id__in=occ_ids).order_by('surah','number').values_list('id','quarter_id'))
        idx_to_qid={i:q for i,(_,q) in enumerate(ay_quarters,start=1)}; expected_qid=idx_to_qid.get(expected)
        if expected_qid==qid:
            cfg=_pages_cfg_get(request); per_pos=cfg['per_pos']; score_now,delta=_grade_push(request,f"إتمام موضع {ar_ordinal(expected)}",+per_pos)
            flow=_flow_mark_completed(request); feedback=_feedback('success',f"تمام! اخترت الربع الصحيح للموضع {ar_ordinal(expected)}. (+{per_pos}%)"); return redirect('core:pages_choose_juz')
        else:
            picked_index=next((i for i,q in idx_to_qid.items() if q==qid),None)
            if picked_index:
                flow['current']=picked_index; request.session['pages_flow']=flow
                score_now,delta=_grade_push(request,"اختيار ربع يخص موضع آخر",-PENALTY_WRONG_QUARTER_OTHER)
                feedback=_feedback('warning',f"الربع المختار يخص الموضع {ar_ordinal(picked_index)} وليس {ar_ordinal(expected)}. سنكمل على هذا الموضع. {delta}%−")
            else:
                score_now,delta=_grade_push(request,"لا يوجد أي موضع في هذا الربع",-PENALTY_EMPTY_QUARTER)
                flow=request.session.get('pages_flow') or {}; current_step=int((flow or {}).get('current') or 1)
                dis=(flow.setdefault('disabled',{}).setdefault(f"step_{current_step}",{'juz':[],'q':[]}))
                if qid not in dis['q']: dis['q'].append(qid)
                request.session['pages_flow']=flow
                quarters=Quarter.objects.filter(juz__number=juz_no_for_q).order_by('index_in_juz')
                ctx={'student':student,'juz_no':juz_no_for_q,'quarters':quarters,'hide_footer':True,'disabled_quarters':dis['q']}
                score_now2,st=_grade_get(request)
                ctx.update({'gauge_score':score_now2,'gauge_events':(st.get('events') or [])[:6],'flow_total':flow.get('total'),'flow_current':flow.get('current'),'flow_completed':flow.get('completed',[])})
                fb=_feedback('error',f"لا يوجد أي موضع في هذا الربع. {delta}%−"); return render(request,'core/pages_choose_quarter.html',_ctx_common(request,ctx,fb,delta))
    pg_nums=Ayah.objects.filter(quarter_id=qid,page__isnull=False).values_list('page__number',flat=True); pg_nums=sorted(set(pg for pg in pg_nums if pg is not None))
    pages=Page.objects.filter(number__in=pg_nums).order_by('number'); ctx={'qid':qid,'pages':pages,'hide_footer':True}
    return render(request,'core/quarter_pages.html',_ctx_common(request,ctx,feedback,delta))

@login_required
@require_POST
def api_pages_select_first(request):
    sid=request.session.get('student_id'); get_object_or_404(Student,id=sid)
    try: ayah_id=int(request.POST.get('ayah_id','0'))
    except ValueError: return JsonResponse({'ok':False,'error':'ayah_id_invalid'},status=400)
    if not Ayah.objects.filter(id=ayah_id).exists(): return JsonResponse({'ok':False,'error':'ayah_not_found'},status=404)
    flow=request.session.get(_ns(request,'pages_flow'),{}) or {}; flow['first_ayah_id']=ayah_id; request.session[_ns(request,'pages_flow')]=flow
    return JsonResponse({'ok':True,'next':'pick_page_position'})

@login_required
def pages_quarter_viewer(request,qid:int):
    sid=request.session.get('student_id'); student=get_object_or_404(Student,id=sid)
    pg_nums=Ayah.objects.filter(quarter_id=qid,page__isnull=False).values_list('page__number',flat=True); pages=sorted(set(p for p in pg_nums if p is not None))
    if not pages:
        quarters=Quarter.objects.filter(id=qid).select_related('juz'); juz_no=quarters[0].juz.number if quarters else None
        if juz_no:
            ctx={'student':student,'juz_no':juz_no,'quarters':Quarter.objects.filter(juz__number=juz_no).order_by('index_in_juz'),'hide_footer':True}
            fb=_feedback('error',"لا توجد صفحات لهذا الربع."); return render(request,'core/pages_choose_quarter.html',_ctx_common(request,ctx,fb,None))
        return redirect('core:pages_choose_juz')
    spreads=[]; i=0
    while i<len(pages):
        left=pages[i]; right=pages[i+1] if i+1<len(pages) else None; spreads.append((left,right)); i+=2
    ctx={'qid':qid,'spreads':spreads,'first_pair':spreads[0],'hide_footer':True}
    return render(request,'core/quarter_viewer.html',_ctx_common(request,ctx))

@login_required
def pages_choose_juz(request):
    sid=request.session.get('student_id'); student=get_object_or_404(Student,id=sid)
    cfg=_pages_cfg_get(request); flow=_flow_get(request)
    if request.headers.get('x-requested-with')=='XMLHttpRequest' and request.GET.get('ajax'):
        if request.GET.get('order')=='1':
            score_now,_=_grade_mark_order(request); request.session['pages_order']=True; ev={'t':"اختيار بالترتيب (Bonus)",'d':PAGES_BONUS_ORDER}
            return JsonResponse({'ok':True,'gauge_score':score_now,'event':ev,'order_mode':True})
        if request.GET.get('set_n'):
            try: n=int(request.GET.get('set_n'))
            except Exception: n=cfg['total']
            cfg,flow=_flow_set_total(request,n); ev={'t':f"تعيين عدد المواضع إلى {cfg['total']}",'d':0}
            return JsonResponse({'ok':True,'flow':flow,'cfg':cfg,'event':ev})
        return JsonResponse({'ok':False},status=400)
    allowed_juz_numbers=_allowed_juz_numbers_for_scope(request)
    context={'student':student,'juz_numbers':allowed_juz_numbers,'had_scope':bool(request.session.get('selected_quarters') or request.session.get('selected_juz')),'hide_footer':True}
    order_param=request.GET.get('order')
    if order_param in ('0','1'):
        if order_param=='1': _grade_mark_order(request); request.session['pages_order']=True
        else: request.session['pages_order']=False
    if not allowed_juz_numbers:
        reason=[]
        if request.session.get('selected_quarters') or request.session.get('selected_juz'): reason.append("النطاق الذي اخترته لا يحتوي على أرباع بها صفحات.")
        else: reason.append("لا توجد صفحات مرتبطة بالأرباع حتى الآن.")
        context['no_juz_reason']=" ".join(reason)
    flow_state=request.session.get('pages_flow') or {}; current_step=int(flow.get('current',1))
    disabled_step=(flow_state.get('disabled',{}) or {}).get(f"step_{current_step}",{'juz':[],'q':[]}); context['disabled_juz']=disabled_step.get('juz',[])
    score_now,st=_grade_get(request)
    context.update({'gauge_score':score_now,'gauge_events':(st.get('events') or [])[:6],'order_mode':bool(request.session.get('pages_order')),'flow_total':flow.get('total'),'flow_current':flow.get('current'),'flow_completed':flow.get('completed',[]),'n_options':list(range(1,11))})
    return render(request,'core/pages_choose_juz.html',_ctx_common(request,context))

@login_required
def pages_choose_quarter(request,juz_no:int):
    sid=request.session.get('student_id'); student=get_object_or_404(Student,id=sid)
    question,flow=_current_question_and_flow(request); feedback=None; delta=None
    quarters=Quarter.objects.filter(juz__number=juz_no).order_by('index_in_juz')
    if question:
        expected=int((request.session.get('pages_flow') or {}).get('current',1))
        occ_ids=question.get('occurrence_ayah_ids',[]) or []
        ay_juzs=Ayah.objects.filter(id__in=occ_ids).order_by('surah','number').values_list('id','quarter__juz__number')
        idx_to_juz={i:j for i,(_,j) in enumerate(ay_juzs,start=1)}; expected_juz=idx_to_juz.get(expected)
        if expected_juz is not None:
            if juz_no==expected_juz: feedback=_feedback('success',"تم اختيار الجزء الصحيح. الآن اختر الربع …"); delta=None
            else:
                picked_index=next((i for i,j in idx_to_juz.items() if j==juz_no),None)
                if picked_index:
                    flow['current']=picked_index; request.session['pages_flow']=flow
                    score_now,delta=_grade_push(request,"اختيار جزء يخص موضع آخر",-PENALTY_WRONG_JUZ_OTHER)
                    feedback=_feedback('warning',f"الجزء المختار يخص الموضع {ar_ordinal(picked_index)} وليس {ar_ordinal(expected)}. سنكمل على هذا الموضع. {delta}%−")
                else:
                    score_now,delta=_grade_push(request,"لا يوجد أي موضع في هذا الجزء",-PENALTY_EMPTY_JUZ)
                    flow=request.session.get('pages_flow') or {}; current_step=int((flow or {}).get('current') or 1)
                    dis=(flow.setdefault('disabled',{}).setdefault(f"step_{current_step}",{'juz':[],'q':[]}))
                    if juz_no not in dis['juz']: dis['juz'].append(juz_no)
                    request.session['pages_flow']=flow; feedback=_feedback('error',f"لا يوجد أي موضع في هذا الجزء. {delta}%−")
    flow_state=request.session.get('pages_flow') or {}; current_step=int((flow or {}).get('current',1))
    disabled_step=(flow_state.get('disabled',{}) or {}).get(f"step_{current_step}",{'juz':[],'q':[]})
    ctx={'student':student,'juz_no':juz_no,'quarters':quarters,'hide_footer':True,'disabled_quarters':disabled_step.get('q',[])}
    score_now,st=_grade_get(request)
    ctx.update({'gauge_score':score_now,'gauge_events':(st.get('events') or [])[:6],'flow_total':flow.get('total'),'flow_current':flow.get('current'),'flow_completed':flow.get('completed',[])})
    return render(request,'core/pages_choose_quarter.html',_ctx_common(request,ctx,feedback,delta))

def _pages_cfg_get(request):
    cfg=request.session.get('pages_cfg') or {}; total=int(cfg.get('total') or 3); per_pos=cfg.get('per_pos')
    if not per_pos: per_pos=round(100/max(1,total),2)
    cfg['total']=total; cfg['per_pos']=per_pos; request.session['pages_cfg']=cfg; return cfg

def _flow_get(request):
    flow=request.session.get('pages_flow') or {}; flow.setdefault('current',1); flow.setdefault('completed',[])
    cfg=_pages_cfg_get(request); flow['total']=cfg['total']; request.session['pages_flow']=flow; return flow

def _flow_set_total(request,n:int):
    cfg=_pages_cfg_get(request); n=max(1,min(50,int(n))); cfg['total']=n; cfg['per_pos']=round(100/n,2); request.session['pages_cfg']=cfg
    flow=_flow_get(request); flow['total']=n; flow['current']=min(flow.get('current',1),n); flow['completed']=[i for i in flow.get('completed',[]) if 1<=int(i)<=n]; request.session['pages_flow']=flow
    return cfg,flow

def _flow_mark_completed(request):
    flow=_flow_get(request); cur=int(flow.get('current',1))
    if cur not in flow['completed']: flow['completed']=list(flow['completed'])+[cur]
    if cur<int(flow.get('total',1)): flow['current']=cur+1
    request.session['pages_flow']=flow; return flow

def _ns(request,base:str)->str:
    sid=request.session.get('db_session_id'); return f"{base}:{sid}" if sid else base

@login_required
def test_next(request):
    tid=request.session.get('db_session_id'); ns=_ns(request,f'flow:{tid}')
    flow=request.session.get(ns) or {'current':1,'total':0}
    flow['current']=min(int(flow.get('current',1))+1,int(flow.get('total',0)) or 1)
    request.session[ns]=flow; request.session.modified=True
    return redirect('core:test_question')

@login_required
def test_prev(request):
    tid=request.session.get('db_session_id'); ns=_ns(request,f'flow:{tid}')
    flow=request.session.get(ns) or {'current':1,'total':0}
    flow['current']=max(int(flow.get('current',1))-1,1)
    request.session[ns]=flow; request.session.modified=True
    return redirect('core:test_question')

class FlowSmokeTest(TestCase):
    def setUp(self):
        User = get_user_model()
        self.u = User.objects.create_user(username='u', password='p')
        self.client.login(username='u', password='p')
        s = self.client.session
        # مبدئياً: امتحان عدّ المواضع
        s['student_id'] = 1
        s['selected_test_type'] = 'similar_count'
        s['selected_juz'] = [1]
        s['num_questions'] = 5
        s['difficulty'] = 'mixed'
        s.save()

    def test_start_initializes_flow(self):
        r = self.client.get(reverse('core:start_test'))
        self.assertEqual(r.status_code, 302)
        s = self.client.session
        tid = s.get('db_session_id')
        self.assertIsNotNone(tid)
        flow = s.get(f'flow:{tid}') or {}
        self.assertEqual(flow.get('current'), 1)
        self.assertGreaterEqual(int(flow.get('total', 0)), 1)

    def test_progress_pct_zero_at_start(self):
        # دي بتقيس كون التقدّم صفر في أول سؤال (لو القالب بيرجّع context)
        self.client.get(reverse('core:start_test'))
        resp = self.client.get(reverse('core:test_question'))
        ctx = getattr(resp, 'context', None)
        # الاختبار ده مرتبط بالتقدّم الداخلي للامتحان الآخر (pages)،
        # لو مش محتاجه هنا ممكن تعلّقه أو تخصص سيناريو similar_on_pages.
        if ctx is not None:
            self.assertIn('progress_pct', ctx)
            self.assertEqual(ctx['progress_pct'], 0)

